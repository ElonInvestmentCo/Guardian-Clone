
  # Replicate Fintech Dashboard UI

  This is a code bundle for Replicate Fintech Dashboard UI. The original project is available at https://www.figma.com/design/I0JsCBHmTRJNQw7YlTHbtL/Replicate-Fintech-Dashboard-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  