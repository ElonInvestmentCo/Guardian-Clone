import Component13HomeV from "@/imports/13HomeV1/index";

export default function App() {
  return (
    <div className="min-h-screen w-full overflow-auto bg-[#f6f8fa]">
      <div className="relative" style={{ width: 1440, minHeight: 1024 }}>
        <Component13HomeV />
      </div>
    </div>
  );
}
