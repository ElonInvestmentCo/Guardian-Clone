import svgPaths from "./svg-eo6a1eepim";
import img03 from "./3db12d1799a7bad8341541bf40270f41dcd8ffa3.png";
import img4 from "./89fe31c79df8fb6bbfd99db1cb18960fb1e8e0e1.png";
import img5 from "./3d5cb72fae1e058c2ed75ab981a9f8bb62e96a13.png";
import img6 from "./75683fd57261c2ae940abab762a6e0130b36b3a9.png";
import img7 from "./232a14a19c4d361cb9f54e38261e75afcd23b9b1.png";
import img8 from "./f0d02ad2f4d075c1fa8155478e5bb26aaae69fc1.png";
import imgEllipse7Stroke from "./4e2e7cd2575f87421b0491fda7a3c80c5bdbfc7b.png";
import imgEllipse7Stroke1 from "./7296165096fd2dfead2ab6d44d1ba37ac4a2471d.png";
import imgEllipse7Stroke2 from "./f694aef7df303cc3655f67652a5748d8a7cd9db1.png";

function Frame27() {
  return (
    <div className="[word-break:break-word] content-stretch flex flex-col items-start justify-center leading-[0] not-italic relative shrink-0 whitespace-nowrap">
      <div className="flex flex-col font-['Poppins:Medium',sans-serif] justify-center relative shrink-0 text-[#0d0d12] text-[16px]">
        <p className="leading-[1.4]">LOGO</p>
      </div>
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center relative shrink-0 text-[#666d80] text-[12px]">
        <p className="leading-[1.55]">Finance App</p>
      </div>
    </div>
  );
}

function Logo() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-name="Logo">
      <div className="h-[36px] relative shrink-0 w-[36.183px]" data-name="Union">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36.1833 36">
          <path d={svgPaths.p34f28a80} fill="var(--fill-0, white)" id="Union" />
        </svg>
      </div>
      <Frame27 />
    </div>
  );
}

function SidebarHeader() {
  return (
    <div className="relative shrink-0 w-full" data-name="Sidebar Header">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-stretch flex items-center justify-between px-[20px] py-[24px] relative size-full">
          <Logo />
          <div className="bg-white content-stretch drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] flex items-center justify-center px-[16px] py-[8px] relative rounded-[1000px] shrink-0 size-[32px]" data-name="Button">
            <div aria-hidden className="absolute border border-[#dfe1e7] border-solid inset-0 pointer-events-none rounded-[1000px]" />
            <div className="overflow-clip relative shrink-0 size-[16px]" data-name="arrow-left-s-line">
              <div className="absolute inset-[23.49%_34.26%_23.48%_33.33%]" data-name="Vector">
                <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5.18547 8.48525">
                  <path d={svgPaths.p1cb6ba00} fill="var(--fill-0, #0D0D12)" id="Vector" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Navlinks() {
  return (
    <div className="bg-white relative rounded-[6px] shrink-0 w-full" data-name="Navlinks">
      <div aria-hidden className="absolute border border-[#dfe1e7] border-solid inset-0 pointer-events-none rounded-[6px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[12px] py-[9px] relative size-full">
          <div className="overflow-clip relative shrink-0 size-[20px]" data-name="home-02">
            <div className="absolute inset-[12.5%_16.67%]" data-name="Icon">
              <div className="absolute inset-[-5.56%_-6.25%]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 16.6667">
                  <path d={svgPaths.p26dd9b80} id="Icon" stroke="url(#paint0_linear_1_1445)" strokeWidth="1.66667" />
                  <defs>
                    <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_1445" x1="7.5" x2="7.5" y1="0.833333" y2="15.8333">
                      <stop stopColor="#272835" />
                      <stop offset="1" stopColor="#72759B" />
                    </linearGradient>
                  </defs>
                </svg>
              </div>
            </div>
          </div>
          <div className="[word-break:break-word] flex flex-col font-['Poppins:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#0d0d12] text-[14px] whitespace-nowrap">
            <p className="leading-[1.55]">Dashboard</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Navlinks1() {
  return (
    <div className="relative rounded-[6px] shrink-0 w-full" data-name="Navlinks">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[12px] py-[10px] relative size-full">
          <div className="overflow-clip relative shrink-0 size-[20px]" data-name="cash-line">
            <div className="absolute inset-[16.68%_8.31%_16.65%_8.35%]" data-name="Vector">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.6667 13.3333">
                <path d={svgPaths.p5409000} fill="url(#paint0_linear_1_1525)" id="Vector" />
                <defs>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_1525" x1="8.33334" x2="8.33334" y1="0" y2="13.3333">
                    <stop stopColor="#818898" />
                    <stop offset="1" stopColor="#BDC4D3" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
          <div className="[word-break:break-word] flex flex-col font-['Poppins:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#818898] text-[14px] whitespace-nowrap">
            <p className="leading-[1.55]">Balance</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Navlinks2() {
  return (
    <div className="relative rounded-[6px] shrink-0 w-full" data-name="Navlinks">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[12px] py-[10px] relative size-full">
          <div className="overflow-clip relative shrink-0 size-[20px]" data-name="bank-card-line">
            <div className="absolute inset-[12.5%_8.31%_12.5%_8.35%]" data-name="Vector">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.6667 15">
                <path d={svgPaths.p13dcd780} fill="url(#paint0_linear_1_1590)" id="Vector" />
                <defs>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_1590" x1="8.33334" x2="8.33334" y1="0" y2="15">
                    <stop stopColor="#818898" />
                    <stop offset="1" stopColor="#BDC4D3" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
          <div className="[word-break:break-word] flex flex-col font-['Poppins:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#818898] text-[14px] whitespace-nowrap">
            <p className="leading-[1.55]">Cards</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Navlinks3() {
  return (
    <div className="relative rounded-[6px] shrink-0 w-full" data-name="Navlinks">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[12px] py-[10px] relative size-full">
          <div className="overflow-clip relative shrink-0 size-[20px]" data-name="exchange-2-line">
            <div className="absolute inset-[10.42%]" data-name="Vector">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.8333 15.8333">
                <path d={svgPaths.p12cd9980} fill="url(#paint0_linear_1_1577)" id="Vector" />
                <defs>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_1577" x1="7.91667" x2="7.91667" y1="0" y2="15.8333">
                    <stop stopColor="#818898" />
                    <stop offset="1" stopColor="#BDC4D3" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
          <div className="[word-break:break-word] flex flex-col font-['Poppins:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#818898] text-[14px] whitespace-nowrap">
            <p className="leading-[1.55]">Transactions</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Navlinks4() {
  return (
    <div className="relative rounded-[6px] shrink-0 w-full" data-name="Navlinks">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[12px] py-[10px] relative size-full">
          <div className="overflow-clip relative shrink-0 size-[20px]" data-name="team-line">
            <div className="absolute inset-[8.33%]" data-name="Vector">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.6667 16.6667">
                <path d={svgPaths.p15370e40} fill="url(#paint0_linear_1_1581)" id="Vector" />
                <defs>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_1581" x1="8.33333" x2="8.33333" y1="0" y2="16.6667">
                    <stop stopColor="#818898" />
                    <stop offset="1" stopColor="#BDC4D3" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
          <div className="[word-break:break-word] flex flex-col font-['Poppins:SemiBold',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#818898] text-[14px] whitespace-nowrap">
            <p className="leading-[1.55]">Recipients</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function MainNavlinks() {
  return (
    <div className="content-stretch flex flex-col gap-[2px] items-start relative shrink-0 w-full" data-name="Main Navlinks">
      <Navlinks />
      <Navlinks1 />
      <Navlinks2 />
      <Navlinks3 />
      <Navlinks4 />
    </div>
  );
}

function Main() {
  return (
    <div className="relative shrink-0 w-full" data-name="Main">
      <div className="content-stretch flex flex-col gap-[12px] items-start px-[12px] relative size-full">
        <div className="[word-break:break-word] flex flex-col font-['Poppins:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#818898] text-[12px] whitespace-nowrap">
          <p className="leading-[1.55]">MAIN</p>
        </div>
        <MainNavlinks />
      </div>
    </div>
  );
}

function Frame5() {
  return (
    <div className="relative rounded-[6px] shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[12px] py-[10px] relative size-full">
          <div className="overflow-clip relative shrink-0 size-[20px]" data-name="apps-2-line">
            <div className="absolute inset-[10.42%]" data-name="Vector">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.8333 15.8333">
                <path d={svgPaths.p2fb42d80} fill="url(#paint0_linear_1_1575)" id="Vector" />
                <defs>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_1575" x1="7.91667" x2="7.91667" y1="0" y2="15.8333">
                    <stop stopColor="#818898" />
                    <stop offset="1" stopColor="#BDC4D3" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
          <div className="[word-break:break-word] flex flex-col font-['Poppins:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#818898] text-[14px] whitespace-nowrap">
            <p className="leading-[1.55]">Integrations</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame6() {
  return (
    <div className="relative rounded-[6px] shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[12px] py-[10px] relative size-full">
          <div className="overflow-clip relative shrink-0 size-[20px]" data-name="settings-3-line">
            <div className="absolute inset-[8.33%_9.84%]" data-name="Vector">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.064 16.6695">
                <path d={svgPaths.p2d30e640} fill="url(#paint0_linear_1_1565)" id="Vector" />
                <defs>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_1565" x1="8.03199" x2="8.03199" y1="7.83415e-09" y2="16.6695">
                    <stop stopColor="#818898" />
                    <stop offset="1" stopColor="#BDC4D3" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
          <div className="[word-break:break-word] flex flex-col font-['Poppins:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#818898] text-[14px] whitespace-nowrap">
            <p className="leading-[1.55]">Settings</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame7() {
  return (
    <div className="relative rounded-[6px] shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[12px] items-center px-[12px] py-[10px] relative size-full">
          <div className="overflow-clip relative shrink-0 size-[20px]" data-name="question-line">
            <div className="absolute inset-[8.33%]" data-name="Vector">
              <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.6667 16.6667">
                <path d={svgPaths.p15819080} fill="url(#paint0_linear_1_1561)" id="Vector" />
                <defs>
                  <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_1561" x1="8.33333" x2="8.33333" y1="0" y2="16.6667">
                    <stop stopColor="#818898" />
                    <stop offset="1" stopColor="#BDC4D3" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
          <div className="[word-break:break-word] flex flex-col font-['Poppins:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#818898] text-[14px] whitespace-nowrap">
            <p className="leading-[1.55]">Get Help</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function OtherNavlinks() {
  return (
    <div className="content-stretch flex flex-col gap-[2px] items-start relative shrink-0 w-full" data-name="Other Navlinks">
      <Frame5 />
      <Frame6 />
      <Frame7 />
    </div>
  );
}

function Other() {
  return (
    <div className="relative shrink-0 w-full" data-name="Other">
      <div className="content-stretch flex flex-col gap-[12px] items-start px-[12px] relative size-full">
        <div className="[word-break:break-word] flex flex-col font-['Poppins:Medium',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#818898] text-[12px] whitespace-nowrap">
          <p className="leading-[1.55]">OTHER</p>
        </div>
        <OtherNavlinks />
      </div>
    </div>
  );
}

function Top() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] items-start relative shrink-0 w-full" data-name="Top">
      <SidebarHeader />
      <Main />
      <Other />
    </div>
  );
}

function Frame24() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0">
      <div className="overflow-clip relative shrink-0 size-[20px]" data-name="customer-service-2-line">
        <div className="absolute inset-[4.17%]" data-name="Vector">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.3333 18.3333">
            <path d={svgPaths.p3f87480} fill="var(--fill-0, #0D0D12)" id="Vector" />
          </svg>
        </div>
      </div>
      <p className="[word-break:break-word] font-['Poppins:Medium',sans-serif] leading-[1.55] not-italic relative shrink-0 text-[#0d0d12] text-[14px] whitespace-nowrap">Need Support?</p>
    </div>
  );
}

function Frame26() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full">
      <Frame24 />
      <div className="overflow-clip relative shrink-0 size-[20px]" data-name="close-fill">
        <div className="absolute inset-[23.49%_23.48%_23.48%_23.48%]" data-name="Vector">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.6066 10.6066">
            <path d={svgPaths.p1f073a00} fill="var(--fill-0, #0D0D12)" id="Vector" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Frame25() {
  return (
    <div className="bg-white relative rounded-[8px] shrink-0 w-full">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col gap-[9px] items-start p-[12px] relative size-full">
          <Frame26 />
          <p className="[word-break:break-word] font-['Poppins:Regular',sans-serif] leading-[1.55] not-italic relative shrink-0 text-[#666d80] text-[12px] w-full">contact with one of our experts to get supports</p>
          <div className="bg-white drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] h-[32px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
            <div aria-hidden className="absolute border border-[#dfe1e7] border-solid inset-0 pointer-events-none rounded-[8px]" />
            <div className="flex flex-row items-center justify-center size-full">
              <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] py-[8px] relative size-full">
                <p className="[word-break:break-word] font-['Poppins:Medium',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#0d0d12] text-[14px] text-center tracking-[0.14px] whitespace-nowrap">Contact Us</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame28() {
  return (
    <div className="[word-break:break-word] content-stretch flex flex-col items-start justify-center leading-[0] not-italic relative shrink-0 whitespace-nowrap">
      <div className="flex flex-col font-['Poppins:Medium',sans-serif] justify-center relative shrink-0 text-[#f8f5ff] text-[14px]">
        <p className="leading-[1.55]">Alexajohn</p>
      </div>
      <div className="flex flex-col font-['Poppins:Regular',sans-serif] justify-center relative shrink-0 text-[#818898] text-[12px]">
        <p className="leading-[1.55]">John@mail.com</p>
      </div>
    </div>
  );
}

function Logo1() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-name="Logo">
      <div className="overflow-clip relative rounded-[99px] shrink-0 size-[40px]" data-name="03">
        <div aria-hidden className="absolute inset-0 pointer-events-none">
          <div className="absolute bg-[#b9cfd0] inset-0" />
          <img alt="" className="absolute max-w-none object-cover size-full" src={img03} />
          <img alt="" className="absolute max-w-none object-cover size-full" src={img4} />
          <img alt="" className="absolute max-w-none object-cover size-full" src={img5} />
          <img alt="" className="absolute max-w-none object-cover size-full" src={img6} />
          <img alt="" className="absolute max-w-none object-cover size-full" src={img7} />
          <img alt="" className="absolute max-w-none object-cover size-full" src={img8} />
          <img alt="" className="absolute max-w-none object-cover size-full" src={img7} />
        </div>
      </div>
      <Frame28 />
    </div>
  );
}

function SidebarFooter() {
  return (
    <div className="relative rounded-[9px] shrink-0 w-full" data-name="Sidebar Footer">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-stretch flex items-center justify-between p-[12px] relative size-full">
          <Logo1 />
          <div className="flex items-center justify-center relative shrink-0">
            <div className="-scale-y-100 flex-none rotate-180">
              <div className="bg-white content-stretch drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] flex items-center justify-center px-[16px] py-[8px] relative rounded-[1000px] size-[32px]" data-name="Button">
                <div aria-hidden className="absolute border border-[#dfe1e7] border-solid inset-0 pointer-events-none rounded-[1000px]" />
                <div className="overflow-clip relative shrink-0 size-[16px]" data-name="arrow-left-s-line">
                  <div className="absolute inset-[23.49%_34.26%_23.48%_33.33%]" data-name="Vector">
                    <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5.18547 8.48525">
                      <path d={svgPaths.p1cb6ba00} fill="var(--fill-0, #0D0D12)" id="Vector" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame3() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="content-stretch flex flex-col gap-[12px] items-start px-[12px] relative size-full">
        <Frame25 />
        <SidebarFooter />
      </div>
    </div>
  );
}

function Footer() {
  return (
    <div className="content-stretch flex flex-col items-start justify-end relative shrink-0 w-full" data-name="Footer">
      <Frame3 />
    </div>
  );
}

function DashboardTitle() {
  return (
    <div className="[word-break:break-word] content-stretch flex flex-[1_0_0] flex-col gap-[4px] h-[66px] items-start min-w-px not-italic relative" data-name="Dashboard Title">
      <p className="font-['Poppins:Medium',sans-serif] leading-[1.5] relative shrink-0 text-[#0d0d12] text-[24px] w-full">Your Financial Dashboard</p>
      <p className="font-['Poppins:Regular',sans-serif] leading-[1.6] relative shrink-0 text-[#666d80] text-[16px] w-full">Welcome back, Max Verstappen!</p>
    </div>
  );
}

function Right() {
  return (
    <div className="content-stretch flex gap-[20px] items-center relative shrink-0" data-name="Right">
      <div className="bg-white content-stretch flex items-center justify-center px-[16px] py-[8px] relative rounded-[1000px] shrink-0 size-[48px]" data-name="Button">
        <div className="overflow-clip relative shrink-0 size-[20px]" data-name="search-line">
          <div className="absolute inset-[8.33%_7.03%_7.03%_8.33%]" data-name="Vector">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.9281 16.9281">
              <path d={svgPaths.pb781390} fill="var(--fill-0, #0D0D12)" id="Vector" />
            </svg>
          </div>
        </div>
      </div>
      <div className="bg-white content-stretch flex items-center justify-center px-[16px] py-[8px] relative rounded-[1000px] shrink-0 size-[48px]" data-name="Button">
        <div className="overflow-clip relative shrink-0 size-[20px]" data-name="notification-2-line">
          <div className="absolute inset-[8.33%_8.33%_2.08%_8.33%]" data-name="Vector">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.6667 17.9167">
              <path d={svgPaths.p17e5fd00} fill="var(--fill-0, #0D0D12)" id="Vector" />
            </svg>
          </div>
        </div>
      </div>
      <div className="bg-white content-stretch drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] flex gap-[8px] h-[48px] items-center justify-center px-[16px] py-[8px] relative rounded-[10px] shrink-0" data-name="Button">
        <div aria-hidden className="absolute border border-[#dfe1e7] border-solid inset-0 pointer-events-none rounded-[10px]" />
        <p className="[word-break:break-word] font-['Poppins:Medium',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#0d0d12] text-[16px] text-center tracking-[0.16px] whitespace-nowrap">{` Exchange Rate`}</p>
      </div>
    </div>
  );
}

function Header() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[1104px]" data-name="Header">
      <DashboardTitle />
      <Right />
    </div>
  );
}

function Actions() {
  return (
    <div className="content-stretch flex gap-[12px] items-start relative shrink-0" data-name="Actions">
      <div className="bg-white content-stretch drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] flex gap-[8px] h-[40px] items-center justify-center px-[16px] py-[8px] relative rounded-[8px] shrink-0" data-name="Button">
        <div aria-hidden className="absolute border border-[#dfe1e7] border-solid inset-0 pointer-events-none rounded-[8px]" />
        <div className="overflow-clip relative shrink-0 size-[20px]" data-name="calendar-line">
          <div className="absolute inset-[4.17%_8.33%_12.5%_8.33%]" data-name="Vector">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.6667 16.6667">
              <path d={svgPaths.p2b074300} fill="var(--fill-0, #0D0D12)" id="Vector" />
            </svg>
          </div>
        </div>
        <p className="[word-break:break-word] font-['Poppins:Medium',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#0d0d12] text-[14px] text-center tracking-[0.14px] whitespace-nowrap">8 Feb - 15 Feb 2024</p>
      </div>
      <div className="bg-white content-stretch drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] flex gap-[8px] h-[40px] items-center justify-center px-[16px] py-[8px] relative rounded-[8px] shrink-0" data-name="Button">
        <div aria-hidden className="absolute border border-[#dfe1e7] border-solid inset-0 pointer-events-none rounded-[8px]" />
        <div className="overflow-clip relative shrink-0 size-[20px]" data-name="filter-3-line">
          <div className="absolute bottom-1/4 left-[12.5%] right-[12.5%] top-1/4" data-name="Vector">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 10">
              <path d={svgPaths.p2cb87d00} fill="var(--fill-0, #0D0D12)" id="Vector" />
            </svg>
          </div>
        </div>
        <p className="[word-break:break-word] font-['Poppins:Medium',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#0d0d12] text-[14px] text-center tracking-[0.14px] whitespace-nowrap">Filter</p>
      </div>
    </div>
  );
}

function TabsFilters() {
  return (
    <div className="content-stretch flex items-end justify-between relative shrink-0 w-[1104px]" data-name="Tabs + Filters">
      <div className="flex flex-row items-end self-stretch">
        <div className="bg-[#eceff3] h-full relative rounded-[8px] shrink-0 w-[327px]" data-name="Segmented Controls">
          <div className="flex flex-row items-center justify-center size-full">
            <div className="content-stretch flex items-center justify-center p-[2px] relative size-full">
              <div className="flex-[1_0_0] h-full min-w-px relative rounded-[8px]">
                <div className="-translate-x-1/2 -translate-y-1/2 [word-break:break-word] absolute flex flex-col font-['Poppins:Medium',sans-serif] justify-center leading-[0] left-1/2 not-italic text-[#666d80] text-[14px] text-center top-1/2 whitespace-nowrap">
                  <p className="leading-[1.55]">12 M</p>
                </div>
              </div>
              <div className="bg-white drop-shadow-[0px_0px_0.5px_rgba(20,20,20,0.04),0px_0px_4px_rgba(20,20,20,0.08)] flex-[1_0_0] h-full min-w-px relative rounded-[6px]">
                <div className="-translate-x-1/2 -translate-y-1/2 [word-break:break-word] absolute flex flex-col font-['Poppins:Medium',sans-serif] justify-center leading-[0] left-1/2 not-italic text-[#0d0d12] text-[14px] text-center top-1/2 whitespace-nowrap">
                  <p className="leading-[1.55]">1 M</p>
                </div>
              </div>
              <div className="flex-[1_0_0] h-full min-w-px relative rounded-[8px]">
                <div className="-translate-x-1/2 -translate-y-1/2 [word-break:break-word] absolute flex flex-col font-['Poppins:Medium',sans-serif] justify-center leading-[0] left-1/2 not-italic text-[#666d80] text-[14px] text-center top-1/2 whitespace-nowrap">
                  <p className="leading-[1.55]">7 D</p>
                </div>
              </div>
              <div className="flex-[1_0_0] h-full min-w-px relative rounded-[8px]">
                <div className="-translate-x-1/2 -translate-y-1/2 [word-break:break-word] absolute flex flex-col font-['Poppins:Medium',sans-serif] justify-center leading-[0] left-1/2 not-italic text-[#666d80] text-[14px] text-center top-1/2 whitespace-nowrap">
                  <p className="leading-[1.55]">24 H</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Actions />
    </div>
  );
}

function Frame() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Frame">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Frame">
          <path d="M16 16H0V0H16V16Z" stroke="var(--stroke-0, #E5E7EB)" />
          <path d={svgPaths.p240fce00} fill="var(--fill-0, #4B5563)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Svg() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 size-[16px] top-[4px]" data-name="svg">
      <Frame />
    </div>
  );
}

function I() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-0 top-0 w-[16px]" data-name="i">
      <Svg />
    </div>
  );
}

function Div2() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-0 top-0 w-[114.031px]" data-name="div">
      <I />
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[24px] leading-[24px] left-[24px] not-italic text-[#1f2937] text-[16px] top-0 w-[91px]">My Balance</p>
    </div>
  );
}

function Frame1() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Frame">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Frame">
          <g clipPath="url(#clip0_1_1376)">
            <path d={svgPaths.p17782e00} fill="var(--fill-0, #9CA3AF)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_1376">
            <path d="M0 0H14V14H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg1() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 size-[14px] top-[1.75px]" data-name="svg">
      <Frame1 />
    </div>
  );
}

function I1() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[17px] left-[90.63px] top-px w-[14px]" data-name="i">
      <Svg1 />
    </div>
  );
}

function Button() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[20px] left-[202.7px] top-[2px] w-[104.625px]" data-name="button">
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[normal] left-[41.3px] not-italic text-[#9ca3af] text-[14px] text-center top-px w-[88px]">More Option</p>
      <I1 />
    </div>
  );
}

function Div1() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-[25px] top-[25px] w-[307.328px]" data-name="div">
      <Div2 />
      <Button />
    </div>
  );
}

function Div3() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[20px] left-[25px] top-[65px] w-[307.328px]" data-name="div">
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[20px] left-0 not-italic text-[#4b5563] text-[14px] top-0 w-[59px]">US Dolar</p>
    </div>
  );
}

function Div4() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[36px] left-[25px] top-[101px] w-[307.328px]" data-name="div">
      <p className="[word-break:break-word] absolute font-['Inter:Bold',sans-serif] font-bold h-[36px] leading-[normal] left-0 not-italic text-[#1f2937] text-[30px] top-0 w-[173px]">$63,48,100</p>
    </div>
  );
}

function Frame2() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Frame">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Frame">
          <g clipPath="url(#clip0_1_1527)">
            <path d={svgPaths.p1865080} fill="var(--fill-0, #16A34A)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_1527">
            <path d="M0 0H14V14H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg2() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 size-[14px] top-[2.75px]" data-name="svg">
      <Frame2 />
    </div>
  );
}

function I2() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[20px] left-0 top-0 w-[14px]" data-name="i">
      <Svg2 />
    </div>
  );
}

function Div5() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[20px] left-[25px] top-[145px] w-[307.328px]" data-name="div">
      <I2 />
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[20px] left-[18px] not-italic text-[#16a34a] text-[14px] top-0 w-[162px]">15.43% Than last month</p>
    </div>
  );
}

function Frame4() {
  return (
    <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Frame">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
        <g id="Frame">
          <g clipPath="url(#clip0_1_1515)">
            <path d={svgPaths.p36e63c00} fill="var(--fill-0, white)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_1515">
            <path d="M0 0H12V16H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg3() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-center justify-center left-0 top-[4px] w-[12px]" data-name="svg">
      <Frame4 />
    </div>
  );
}

function I3() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-[44.2px] top-[12px] w-[12px]" data-name="i">
      <Svg3 />
    </div>
  );
}

function Button1() {
  return (
    <div className="absolute bg-[#1f2937] border-0 border-[#e5e7eb] border-solid h-[48px] left-0 rounded-[8px] top-0 w-[147.672px]" data-name="button">
      <I3 />
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[24px] leading-[normal] left-[86.7px] not-italic text-[16px] text-center text-white top-[14px] w-[45px]">Send</p>
    </div>
  );
}

function Frame8() {
  return (
    <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Frame">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
        <g id="Frame">
          <g clipPath="url(#clip0_1_1481)">
            <path d={svgPaths.p3f425280} fill="var(--fill-0, white)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_1481">
            <path d="M0 0H12V16H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg4() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-center justify-center left-0 top-[4px] w-[12px]" data-name="svg">
      <Frame8 />
    </div>
  );
}

function I4() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-[32.56px] top-[12px] w-[12px]" data-name="i">
      <Svg4 />
    </div>
  );
}

function Button2() {
  return (
    <div className="absolute bg-[#1f2937] border-0 border-[#e5e7eb] border-solid h-[48px] left-[159.67px] rounded-[8px] top-0 w-[147.672px]" data-name="button">
      <I4 />
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[24px] leading-[normal] left-[86.56px] not-italic text-[16px] text-center text-white top-[14px] w-[68px]">Request</p>
    </div>
  );
}

function Div6() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[48px] left-[25px] top-[240px] w-[307.328px]" data-name="div">
      <Button1 />
      <Button2 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute inset-[10.87%_0_0_1.72%]" data-name="Group">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 23.5866 21.3913">
        <g id="Group">
          <path d={svgPaths.p2ad02800} fill="var(--fill-0, #D80027)" id="Vector" />
          <path d={svgPaths.p26d7fc80} fill="var(--fill-0, #D80027)" id="Vector_2" />
          <path d={svgPaths.p12b80500} fill="var(--fill-0, #D80027)" id="Vector_3" />
          <path d={svgPaths.p18adb800} fill="var(--fill-0, #D80027)" id="Vector_4" />
        </g>
      </svg>
    </div>
  );
}

function Div() {
  return (
    <div className="bg-white h-[306px] relative rounded-[12px] shrink-0 w-[351px]" data-name="div">
      <div aria-hidden className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <Div1 />
      <Div3 />
      <Div4 />
      <Div5 />
      <Div6 />
      <div className="absolute left-[89px] overflow-clip size-[24px] top-[63px]" data-name="united states">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
          <path d={svgPaths.p1c665200} fill="var(--fill-0, white)" id="Vector" />
        </svg>
        <Group />
        <div className="absolute bottom-1/2 left-0 right-1/2 top-0" data-name="Vector">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
            <path d={svgPaths.p199b9d00} fill="var(--fill-0, #0052B4)" id="Vector" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Frame9() {
  return (
    <div className="h-[16px] relative shrink-0 w-[18px]" data-name="Frame">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 16">
        <g id="Frame">
          <path d="M18 16H0V0H18V16Z" stroke="var(--stroke-0, #E5E7EB)" />
          <path d={svgPaths.p1db3ae0} fill="var(--fill-0, #4B5563)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Svg5() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-center justify-center left-0 top-[4px] w-[18px]" data-name="svg">
      <Frame9 />
    </div>
  );
}

function I5() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-0 top-0 w-[18px]" data-name="i">
      <Svg5 />
    </div>
  );
}

function Div9() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-0 top-0 w-[100.094px]" data-name="div">
      <I5 />
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[24px] leading-[24px] left-[26px] not-italic text-[#1f2937] text-[16px] top-0 w-[75px]">My Cards</p>
    </div>
  );
}

function Button3() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[20px] left-[211.38px] top-[2px] w-[95.969px]" data-name="button">
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[normal] left-[48px] not-italic text-[#4b5563] text-[14px] text-center top-px w-[96px]">+ More Option</p>
    </div>
  );
}

function Div8() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-[24.66px] top-[25px] w-[307.344px]" data-name="div">
      <Div9 />
      <Button3 />
    </div>
  );
}

function Button4() {
  return (
    <div className="absolute bg-[#f3f4f6] border-0 border-[#e5e7eb] border-solid h-[40px] left-0 rounded-[8px] top-0 w-[82.031px]" data-name="button">
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[24px] leading-[normal] left-[44px] not-italic text-[#1f2937] text-[16px] text-center top-[10px] w-[56px]">Virtual</p>
    </div>
  );
}

function Button5() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[40px] left-[90.03px] top-0 w-[96.016px]" data-name="button">
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[24px] leading-[normal] left-[51px] not-italic text-[#4b5563] text-[16px] text-center top-[10px] w-[70px]">Physical</p>
    </div>
  );
}

function Div10() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[40px] left-[24.66px] top-[65px] w-[307.344px]" data-name="div">
      <Button4 />
      <Button5 />
    </div>
  );
}

function MaskGroup() {
  return (
    <div className="absolute h-[180.81px] left-[25px] top-[115px] w-[286.232px]" data-name="Mask Group">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 286.232 180.81">
        <g id="Mask Group">
          <mask height="181" id="mask0_1_1391" maskUnits="userSpaceOnUse" style={{ maskType: "alpha" }} width="287" x="0" y="0">
            <rect fill="var(--fill-0, #194BFB)" height="180.81" id="Rectangle 4" rx="15.0675" width="286.232" />
          </mask>
          <g mask="url(#mask0_1_1391)">
            <path d={svgPaths.p3d9e9900} fill="url(#paint0_linear_1_1391)" fillOpacity="0.9" id="Ellipse 77" />
            <path d={svgPaths.p34ad8d00} fill="url(#paint1_linear_1_1391)" fillOpacity="0.9" id="Ellipse 78" />
          </g>
        </g>
        <defs>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_1391" x1="86.2309" x2="209.031" y1="90.4051" y2="90.4051">
            <stop stopColor="white" stopOpacity="0.15" />
            <stop offset="1" stopColor="white" stopOpacity="0" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_1_1391" x1="195.487" x2="291.65" y1="90.4045" y2="90.4045">
            <stop stopColor="white" stopOpacity="0.15" />
            <stop offset="1" stopColor="white" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute inset-[12.5%_0_11.31%_0]">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 28.8941 22.0146">
        <g id="Group 244">
          <rect fill="url(#paint0_linear_1_1518)" height="21.5437" id="Rectangle" rx="3.53144" stroke="var(--stroke-0, #9F7E3B)" strokeWidth="0.470859" width="28.4233" x="0.235429" y="0.235429" />
          <path d={svgPaths.p1ba05140} id="Vector 174" stroke="var(--stroke-0, black)" strokeOpacity="0.76" strokeWidth="0.470859" />
          <path d={svgPaths.p1d349cc0} id="Vector 175" stroke="var(--stroke-0, black)" strokeOpacity="0.76" strokeWidth="0.470859" />
        </g>
        <defs>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_1518" x1="0" x2="28.8941" y1="0" y2="22.1221">
            <stop stopColor="#E6AC3C" />
            <stop offset="1" stopColor="#FFDA93" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Logo2() {
  return (
    <div className="absolute inset-[47.02%_12.41%_46.63%_68.62%]" data-name="Logo">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 65.8546 19.422">
        <g id="Logo">
          <g id="Shape">
            <path d={svgPaths.p27009f00} fill="var(--fill-0, white)" id="Subtract" opacity="0.6" />
            <path clipRule="evenodd" d={svgPaths.p3baf6c80} fill="var(--fill-0, white)" fillRule="evenodd" id="Subtract_2" />
          </g>
          <g id="BankCo.">
            <path d={svgPaths.pfe4fe00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p30d4d0c0} fill="var(--fill-0, white)" />
            <path d={svgPaths.p47057f0} fill="var(--fill-0, white)" />
            <path d={svgPaths.p3a8bc80} fill="var(--fill-0, white)" />
          </g>
          <g id="BankCo._2">
            <path d={svgPaths.p29d22100} fill="var(--fill-0, white)" />
            <path d={svgPaths.p31297d00} fill="var(--fill-0, white)" />
            <path d={svgPaths.p1a6bac00} fill="var(--fill-0, white)" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute inset-[20.83%_8.33%]" data-name="Group">
      <div className="absolute inset-[-8.38%_-5.87%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.4518 9.84003">
          <g id="Group">
            <path d={svgPaths.p26221e80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.41258" />
            <path d={svgPaths.p14201bb0} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.41258" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents left-[57.51px] top-[214.28px]">
      <div className="absolute inset-[80.37%_13.43%_14.91%_72.78%]" data-name="Vector">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 47.8559 14.4471">
          <path d={svgPaths.p160d1980} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <div className="-translate-y-1/2 [word-break:break-word] absolute flex flex-col font-['Urbanist:Medium',sans-serif] font-medium justify-center leading-[0] left-[57.51px] opacity-60 text-[11.301px] text-white top-[222.78px] tracking-[0.3767px] whitespace-nowrap">
        <p className="leading-[1.5]">Balance</p>
      </div>
      <div className="-translate-y-1/2 [word-break:break-word] absolute flex flex-col font-['Urbanist:Bold',sans-serif] font-bold justify-center leading-[0] left-[57.51px] text-[22.601px] text-white top-[252.26px] whitespace-nowrap">
        <p className="leading-[1.3]">$24,098.00</p>
      </div>
      <div className="absolute left-[108.07px] opacity-60 overflow-clip size-[14.447px] top-[216.13px]" data-name="eye">
        <Group1 />
      </div>
    </div>
  );
}

function Card() {
  return (
    <div className="absolute contents left-[25px] top-[115px]" data-name="card">
      <div className="absolute bg-[#191b23] h-[180.81px] left-[25px] rounded-[11.301px] top-[115px] w-[307px]" />
      <MaskGroup />
      <div className="absolute inset-[45.55%_75.36%_45.01%_16.31%]" data-name="Chips">
        <Group2 />
      </div>
      <Logo2 />
      <Group3 />
    </div>
  );
}

function Div7() {
  return (
    <div className="bg-white h-[306px] relative rounded-[12px] shrink-0 w-[347px]" data-name="div">
      <div aria-hidden className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <Div8 />
      <Div10 />
      <Card />
    </div>
  );
}

function Title() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[8px] items-center min-w-px relative" data-name="Title">
      <div className="overflow-clip relative shrink-0 size-[24px]" data-name="pie-chart-2-line">
        <div className="absolute inset-[2.08%_2.08%_8.33%_8.33%]" data-name="Vector">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 21.5 21.5">
            <path d={svgPaths.p27c2900} fill="var(--fill-0, #0D0D12)" id="Vector" />
          </svg>
        </div>
      </div>
      <p className="[word-break:break-word] flex-[1_0_0] font-['Poppins:Medium',sans-serif] leading-[1.4] min-w-px not-italic relative text-[#0d0d12] text-[16px]">Spending Summary</p>
    </div>
  );
}

function SectionHeader() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0 w-full" data-name="Section header">
      <Title />
      <div className="bg-white content-stretch drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] flex gap-[8px] h-[32px] items-center justify-center px-[16px] py-[8px] relative rounded-[6px] shrink-0" data-name="Button">
        <div aria-hidden className="absolute border border-[#dfe1e7] border-solid inset-0 pointer-events-none rounded-[6px]" />
        <p className="[word-break:break-word] font-['Poppins:Medium',sans-serif] leading-[1.55] not-italic relative shrink-0 text-[#0d0d12] text-[14px] text-center whitespace-nowrap">More Option</p>
        <div className="overflow-clip relative shrink-0 size-[16px]" data-name="arrow-down-s-line">
          <div className="absolute inset-[34.26%_23.48%_33.33%_23.48%]" data-name="Vector">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8.48527 5.18548">
              <path d={svgPaths.p3cfa0180} fill="var(--fill-0, #0D0D12)" id="Vector" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Content() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Content">
      <SectionHeader />
    </div>
  );
}

function Frame29() {
  return (
    <div className="-translate-x-1/2 [word-break:break-word] absolute bottom-0 content-stretch flex flex-col font-['Poppins:Medium',sans-serif] gap-[4px] items-center justify-center left-[calc(50%-0.5px)] not-italic text-center">
      <p className="leading-[1.55] relative shrink-0 text-[#364152] text-[14px] w-[174px]">Spent</p>
      <p className="leading-[1.5] relative shrink-0 text-[#0d0d12] text-[24px] w-[251px]">$16,654,450</p>
    </div>
  );
}

function Frame31() {
  return (
    <div className="absolute h-[144.427px] left-[25px] top-[-2px] w-[280px]">
      <div className="absolute h-[144.427px] left-0 top-0 w-[280px]" data-name="Ellipse 7 (Stroke)">
        <img alt="" className="absolute block inset-0 max-w-none size-full" height="144.305" src={imgEllipse7Stroke} width="280" />
      </div>
      <div className="absolute h-[144.427px] left-0 top-0 w-[221.419px]" data-name="Ellipse 7 (Stroke)">
        <div className="absolute inset-[0_0.71%_0_0]">
          <img alt="" className="block max-w-none size-full" height="144.305" src={imgEllipse7Stroke1} width="219.837" />
        </div>
      </div>
      <div className="absolute h-[144.121px] left-0 top-[0.31px] w-[133.56px]" data-name="Ellipse 7 (Stroke)">
        <div className="absolute inset-[0.21%_0.14%_0_0]">
          <img alt="" className="block max-w-none size-full" height="143.697" src={imgEllipse7Stroke2} width="133.367" />
        </div>
      </div>
    </div>
  );
}

function PieChart() {
  return (
    <div className="h-[141px] relative shrink-0 w-[330px]" data-name="Pie Chart">
      <Frame29 />
      <Frame31 />
    </div>
  );
}

function Legend() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0" data-name="Legend">
      <div className="bg-[#1a1b25] relative rounded-[29px] shrink-0 size-[10px]" data-name="Mixed" />
      <p className="[word-break:break-word] font-['Poppins:Regular',sans-serif] leading-[1.55] not-italic relative shrink-0 text-[#666d80] text-[12px] whitespace-nowrap">Outcome</p>
    </div>
  );
}

function Legend1() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0" data-name="Legend">
      <div className="bg-[#99c0ff] relative rounded-[29px] shrink-0 size-[10px]" data-name="Mixed" />
      <p className="[word-break:break-word] font-['Poppins:Regular',sans-serif] leading-[1.55] not-italic relative shrink-0 text-[#666d80] text-[12px] whitespace-nowrap">Income</p>
    </div>
  );
}

function Legend2() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0" data-name="Legend">
      <div className="bg-[#c1c7d0] relative rounded-[29px] shrink-0 size-[10px]" data-name="Mixed" />
      <p className="[word-break:break-word] font-['Poppins:Regular',sans-serif] leading-[1.55] not-italic relative shrink-0 text-[#666d80] text-[12px] whitespace-nowrap">Others</p>
    </div>
  );
}

function ChartsLegend() {
  return (
    <div className="content-stretch flex gap-[24px] items-center justify-center relative shrink-0 w-full" data-name="Charts Legend">
      <Legend />
      <Legend1 />
      <Legend2 />
    </div>
  );
}

function Info() {
  return (
    <div className="bg-[#f0fbff] content-stretch flex h-[32px] items-center justify-between px-[16px] py-[8px] relative rounded-[6px] shrink-0 w-[320px]" data-name="Info">
      <p className="[word-break:break-word] font-['Poppins:Regular',sans-serif] leading-[0] not-italic relative shrink-0 text-[#116b97] text-[0px] text-center whitespace-nowrap">
        <span className="leading-[1.55] text-[12px]">{`Your weekly spending limit is `}</span>
        <span className="font-['Poppins:SemiBold',sans-serif] leading-[1.55] text-[12px]">$2000.</span>
      </p>
      <div className="overflow-clip relative shrink-0 size-[16px]" data-name="information-2-line">
        <div className="absolute inset-[8.33%]" data-name="Vector">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.3333 13.3333">
            <path d={svgPaths.p7d9e300} fill="var(--fill-0, #116B97)" id="Vector" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Card1() {
  return (
    <div className="bg-white relative rounded-[16px] shrink-0 w-[352px]" data-name="Card">
      <div className="content-stretch flex flex-col gap-[16px] items-start overflow-clip p-[16px] relative rounded-[inherit] size-full">
        <Content />
        <div className="bg-[#dfe1e7] h-px relative shrink-0 w-full" />
        <PieChart />
        <div className="bg-[#dfe1e7] h-px relative shrink-0 w-full" data-name="Divider" />
        <ChartsLegend />
        <Info />
      </div>
      <div aria-hidden className="absolute border border-[#dfe1e7] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(16,24,40,0.06)]" />
    </div>
  );
}

function Frame10() {
  return (
    <div className="h-[16px] relative shrink-0 w-[14px]" data-name="Frame">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 16">
        <g id="Frame">
          <g clipPath="url(#clip0_1_1542)">
            <path d={svgPaths.pe60b600} fill="var(--fill-0, #4B5563)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_1542">
            <path d="M0 0H14V16H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg6() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-center justify-center left-0 top-[4px] w-[14px]" data-name="svg">
      <Frame10 />
    </div>
  );
}

function I6() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-0 top-0 w-[14px]" data-name="i">
      <Svg6 />
    </div>
  );
}

function Div13() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-0 top-0 w-[155.172px]" data-name="div">
      <I6 />
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[24px] leading-[24px] left-[22px] not-italic text-[#1f2937] text-[16px] top-0 w-[134px]">Budget Overview</p>
    </div>
  );
}

function Div16() {
  return <div className="absolute bg-[#1f2937] border-0 border-[#e5e7eb] border-solid left-0 rounded-[9999px] size-[12px] top-[4px]" data-name="div" />;
}

function Div15() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[20px] left-0 top-0 w-[76.984px]" data-name="div">
      <Div16 />
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[20px] left-[16px] not-italic text-[14px] text-black top-0 w-[61px]">Outcome</p>
    </div>
  );
}

function Div18() {
  return <div className="absolute bg-[#60a5fa] border-0 border-[#e5e7eb] border-solid left-0 rounded-[9999px] size-[12px] top-[4px]" data-name="div" />;
}

function Div17() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[20px] left-[84.98px] top-0 w-[65.438px]" data-name="div">
      <Div18 />
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[20px] left-[16px] not-italic text-[14px] text-black top-0 w-[50px]">Income</p>
    </div>
  );
}

function Div14() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[20px] left-[156.91px] top-[2px] w-[150.422px]" data-name="div">
      <Div15 />
      <Div17 />
    </div>
  );
}

function Div12() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-[25px] top-[25px] w-[307.328px]" data-name="div">
      <Div13 />
      <Div14 />
    </div>
  );
}

function Frame11() {
  return (
    <div className="h-[14px] relative shrink-0 w-[10.5px]" data-name="Frame">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.5 14">
        <g id="Frame">
          <g clipPath="url(#clip0_1_1592)">
            <path d={svgPaths.p1432cb00} fill="var(--fill-0, #22C55E)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_1592">
            <path d="M0 0H10.5V14H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg7() {
  return (
    <div className="absolute content-stretch flex h-[14px] items-center justify-center left-0 top-[1.75px] w-[10.5px]" data-name="svg">
      <Frame11 />
    </div>
  );
}

function I7() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[17px] left-[49.44px] top-px w-[10.5px]" data-name="i">
      <Svg7 />
    </div>
  );
}

function Div21() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[20px] left-0 top-0 w-[145.656px]" data-name="div">
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[normal] left-0 not-italic text-[#4b5563] text-[14px] top-px w-[55px]">Income</p>
      <I7 />
    </div>
  );
}

function Div22() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[28px] left-0 top-[24px] w-[145.656px]" data-name="div">
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[28px] leading-[normal] left-0 not-italic text-[20px] text-black top-[2px] w-[112px]">$17,843.33</p>
    </div>
  );
}

function Div20() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[52px] left-0 top-0 w-[145.656px]" data-name="div">
      <Div21 />
      <Div22 />
    </div>
  );
}

function Frame12() {
  return (
    <div className="h-[14px] relative shrink-0 w-[10.5px]" data-name="Frame">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.5 14">
        <g id="Frame">
          <g clipPath="url(#clip0_1_1478)">
            <path d={svgPaths.p3b9d19f2} fill="var(--fill-0, #EF4444)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_1478">
            <path d="M0 0H10.5V14H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg8() {
  return (
    <div className="absolute content-stretch flex h-[14px] items-center justify-center left-0 top-[1.75px] w-[10.5px]" data-name="svg">
      <Frame12 />
    </div>
  );
}

function I8() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[17px] left-[57.31px] top-px w-[10.5px]" data-name="i">
      <Svg8 />
    </div>
  );
}

function Div24() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[20px] left-0 top-0 w-[145.672px]" data-name="div">
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[normal] left-0 not-italic text-[#4b5563] text-[14px] top-px w-[63px]">Expense</p>
      <I8 />
    </div>
  );
}

function Div25() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[28px] left-0 top-[24px] w-[145.672px]" data-name="div">
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[28px] leading-[normal] left-0 not-italic text-[20px] text-black top-[2px] w-[114px]">$14,256.55</p>
    </div>
  );
}

function Div23() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[52px] left-[161.66px] top-0 w-[145.672px]" data-name="div">
      <Div24 />
      <Div25 />
    </div>
  );
}

function Div19() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[52px] left-[25px] top-[65px] w-[307.328px]" data-name="div">
      <Div20 />
      <Div23 />
    </div>
  );
}

function Line() {
  return (
    <div className="absolute bottom-0 h-[234px] right-0 w-[648px]" data-name="Line">
      <div className="absolute inset-[-0.43%_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 648 235">
          <g id="Line">
            <line id="Line 5" stroke="var(--stroke-0, #DFE1E7)" x2="648" y1="0.5" y2="0.5" />
            <line id="Line 7" stroke="var(--stroke-0, #DFE1E7)" x2="648" y1="47.3" y2="47.3" />
            <line id="Line 8" stroke="var(--stroke-0, #DFE1E7)" x2="648" y1="94.1" y2="94.1" />
            <line id="Line 10" stroke="var(--stroke-0, #DFE1E7)" x2="648" y1="140.9" y2="140.9" />
            <line id="Line 11" stroke="var(--stroke-0, #DFE1E7)" x2="648" y1="187.7" y2="187.7" />
            <line id="Line 12" stroke="var(--stroke-0, #DFE1E7)" x2="648" y1="234.5" y2="234.5" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Value() {
  return (
    <div className="[word-break:break-word] content-stretch flex flex-col font-['Inter:Regular',sans-serif] font-normal gap-[36px] items-start justify-end leading-[18px] not-italic relative shrink-0 text-[#697586] text-[12px] w-[48px] whitespace-nowrap" data-name="Value">
      <p className="[text-box-edge:cap_alphabetic] [text-box-trim:trim-both] relative shrink-0">50K</p>
      <p className="[text-box-edge:cap_alphabetic] [text-box-trim:trim-both] relative shrink-0">40K</p>
      <p className="[text-box-edge:cap_alphabetic] [text-box-trim:trim-both] relative shrink-0">30K</p>
      <p className="[text-box-edge:cap_alphabetic] [text-box-trim:trim-both] relative shrink-0">20K</p>
      <p className="[text-box-edge:cap_alphabetic] [text-box-trim:trim-both] relative shrink-0">10K</p>
      <p className="[text-box-edge:cap_alphabetic] [text-box-trim:trim-both] relative shrink-0">0</p>
    </div>
  );
}

function Chart1() {
  return (
    <div className="content-stretch flex gap-[4px] h-full items-end relative shrink-0" data-name="Chart">
      <div className="h-[96px] relative shrink-0 w-[24px]" data-name="Chart Outcome">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 96">
          <path d={svgPaths.pf58ae80} fill="var(--fill-0, #E5EFFF)" id="Chart Outcome" />
        </svg>
      </div>
      <div className="h-[134px] relative shrink-0 w-[24px]" data-name="Chart Income">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 134">
          <path d={svgPaths.p2ad06e70} fill="var(--fill-0, #666D80)" id="Chart Income" />
        </svg>
      </div>
    </div>
  );
}

function Chart2() {
  return (
    <div className="content-stretch flex gap-[4px] h-full items-end relative shrink-0" data-name="Chart">
      <div className="h-[145px] relative shrink-0 w-[24px]" data-name="Chart Outcome">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 145">
          <path d={svgPaths.p27f28cc0} fill="var(--fill-0, #E5EFFF)" id="Chart Outcome" />
        </svg>
      </div>
      <div className="h-[93px] relative shrink-0 w-[24px]" data-name="Chart Income">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 93">
          <path d={svgPaths.p28f4de80} fill="var(--fill-0, #666D80)" id="Chart Income" />
        </svg>
      </div>
    </div>
  );
}

function Chart3() {
  return (
    <div className="content-stretch flex gap-[4px] h-full items-end relative shrink-0" data-name="Chart">
      <div className="h-[116px] relative shrink-0 w-[24px]" data-name="Chart Outcome">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 116">
          <path d={svgPaths.p2e767d00} fill="var(--fill-0, #E5EFFF)" id="Chart Outcome" />
        </svg>
      </div>
      <div className="h-[170px] relative shrink-0 w-[24px]" data-name="Chart Income">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 170">
          <path d={svgPaths.p325db700} fill="var(--fill-0, #666D80)" id="Chart Income" />
        </svg>
      </div>
    </div>
  );
}

function Chart4() {
  return (
    <div className="content-stretch flex gap-[4px] h-full items-end relative shrink-0" data-name="Chart">
      <div className="h-[191px] relative shrink-0 w-[24px]" data-name="Chart Outcome">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 191">
          <path d={svgPaths.p270ff580} fill="var(--fill-0, #E5EFFF)" id="Chart Outcome" />
        </svg>
      </div>
      <div className="h-[75px] relative shrink-0 w-[24px]" data-name="Chart Income">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 75">
          <path d={svgPaths.p2bd112f0} fill="var(--fill-0, #666D80)" id="Chart Income" />
        </svg>
      </div>
    </div>
  );
}

function Chart5() {
  return (
    <div className="content-stretch flex gap-[4px] h-full items-end relative shrink-0" data-name="Chart">
      <div className="h-[129px] relative shrink-0 w-[24px]" data-name="Chart Outcome">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 129">
          <path d={svgPaths.p1852e900} fill="var(--fill-0, #CCE0FF)" id="Chart Outcome" />
        </svg>
      </div>
      <div className="h-[105px] relative shrink-0 w-[24px]" data-name="Chart Income">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 105">
          <path d={svgPaths.p15230e80} fill="var(--fill-0, #1A1B25)" id="Chart Income" />
        </svg>
      </div>
    </div>
  );
}

function Chart6() {
  return (
    <div className="content-stretch flex gap-[4px] h-full items-end relative shrink-0" data-name="Chart">
      <div className="h-[142px] relative shrink-0 w-[24px]" data-name="Chart Outcome">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 142">
          <path d={svgPaths.p35834800} fill="var(--fill-0, #E5EFFF)" id="Chart Outcome" />
        </svg>
      </div>
      <div className="h-[230px] relative shrink-0 w-[24px]" data-name="Chart Income">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 230">
          <path d={svgPaths.p177d8880} fill="var(--fill-0, #666D80)" id="Chart Income" />
        </svg>
      </div>
    </div>
  );
}

function Chart7() {
  return (
    <div className="content-stretch flex gap-[4px] h-full items-end relative shrink-0" data-name="Chart">
      <div className="h-[117px] relative shrink-0 w-[24px]" data-name="Chart Outcome">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 117">
          <path d={svgPaths.p14500d00} fill="var(--fill-0, #E5EFFF)" id="Chart Outcome" />
        </svg>
      </div>
      <div className="h-[139px] relative shrink-0 w-[24px]" data-name="Chart Income">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 139">
          <path d={svgPaths.p1c365700} fill="var(--fill-0, #666D80)" id="Chart Income" />
        </svg>
      </div>
    </div>
  );
}

function Chart8() {
  return (
    <div className="content-stretch flex gap-[4px] h-full items-end relative shrink-0" data-name="Chart">
      <div className="h-[147px] relative shrink-0 w-[24px]" data-name="Chart Outcome">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 147">
          <path d={svgPaths.p1644bd80} fill="var(--fill-0, #E5EFFF)" id="Chart Outcome" />
        </svg>
      </div>
      <div className="h-[85px] relative shrink-0 w-[24px]" data-name="Chart Income">
        <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 85">
          <path d={svgPaths.p3acd2680} fill="var(--fill-0, #666D80)" id="Chart Income" />
        </svg>
      </div>
    </div>
  );
}

function Charts() {
  return (
    <div className="content-stretch flex gap-[28px] h-[234px] items-start relative shrink-0" data-name="Charts">
      <Chart1 />
      <Chart2 />
      <Chart3 />
      <Chart4 />
      <Chart5 />
      <Chart6 />
      <Chart7 />
      <Chart8 />
    </div>
  );
}

function Chart() {
  return (
    <div className="content-stretch flex gap-[24px] items-end relative shrink-0" data-name="Chart">
      <Line />
      <Value />
      <Charts />
    </div>
  );
}

function Frame30() {
  return <div className="h-[18px] relative shrink-0 w-[48px]" />;
}

function Month() {
  return (
    <div className="[word-break:break-word] content-stretch flex font-['Poppins:Regular',sans-serif] gap-[28px] items-start leading-[1.55] not-italic relative shrink-0 text-[12px] text-center" data-name="Month">
      <p className="relative shrink-0 text-[#697586] w-[52px]">JUN</p>
      <p className="relative shrink-0 text-[#697586] w-[52px]">JUN</p>
      <p className="relative shrink-0 text-[#697586] w-[52px]">JUL</p>
      <p className="relative shrink-0 text-[#697586] w-[52px]">AUG</p>
      <p className="relative shrink-0 text-[#0d0d12] w-[52px]">SEP</p>
      <p className="relative shrink-0 text-[#697586] w-[52px]">OCT</p>
      <p className="relative shrink-0 text-[#697586] w-[52px]">NOV</p>
      <p className="relative shrink-0 text-[#697586] w-[52px]">NOV</p>
    </div>
  );
}

function SumbuX() {
  return (
    <div className="content-stretch flex gap-[24px] items-center relative shrink-0 w-full" data-name="Sumbu X">
      <Frame30 />
      <Month />
    </div>
  );
}

function ChartDetail() {
  return <div className="absolute h-[14px] right-[204px] top-[3px] w-[18px]" data-name="Chart Detail" />;
}

function SlotBarChart() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex flex-col gap-[8px] items-center justify-end left-1/2 top-[141px]" data-name="SLOT/Bar chart">
      <Chart />
      <SumbuX />
      <ChartDetail />
    </div>
  );
}

function Div27() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[16px] left-[8px] top-[8px] w-[71.609px]" data-name="div">
      <p className="[word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium h-[16px] leading-[normal] left-0 not-italic text-[12px] text-white top-0 w-[72px]">SEPTEMBER</p>
    </div>
  );
}

function Div28() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[16px] left-[8px] top-[24px] w-[71.609px]" data-name="div">
      <p className="[word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[16px] leading-[normal] left-0 not-italic text-[#4ade80] text-[12px] top-0 w-[72px]">426 ↑16.2%</p>
    </div>
  );
}

function Div29() {
  return (
    <div className="[word-break:break-word] absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid font-['Inter:Regular',sans-serif] font-normal h-[32px] leading-[normal] left-[8px] not-italic text-[#f87171] text-[12px] top-[40px] w-[71.609px]" data-name="div">
      <p className="absolute h-[16px] left-0 top-0 w-[36px]">1,256</p>
      <p className="absolute h-[16px] left-0 top-[16px] w-[53px]">↓32.5%</p>
    </div>
  );
}

function Div26() {
  return (
    <div className="absolute bg-[#1f2937] border-0 border-[#e5e7eb] border-solid h-[80px] left-[389px] rounded-[4px] top-[134px] w-[87.609px]" data-name="div">
      <Div27 />
      <Div28 />
      <Div29 />
    </div>
  );
}

function Div11() {
  return (
    <div className="bg-white h-[427px] relative rounded-[12px] shrink-0 w-[728px]" data-name="div">
      <div aria-hidden className="absolute border border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <Div12 />
      <Div19 />
      <SlotBarChart />
      <Div26 />
    </div>
  );
}

function Frame13() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Frame">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Frame">
          <path d="M16 16H0V0H16V16Z" stroke="var(--stroke-0, #E5E7EB)" />
          <path d={svgPaths.p1c578e00} fill="var(--fill-0, #1A1A1A)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Svg9() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 size-[16px] top-[4px]" data-name="svg">
      <Frame13 />
    </div>
  );
}

function I9() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-0 top-0 w-[16px]" data-name="i">
      <Svg9 />
    </div>
  );
}

function Div32() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-0 top-0 w-[182.234px]" data-name="div">
      <I9 />
      <p className="[word-break:break-word] absolute font-['Inter:Semi_Bold',sans-serif] font-semibold h-[24px] leading-[24px] left-[24px] not-italic text-[#1a1a1a] text-[16px] top-0 w-[159px]">Recent Transactions</p>
    </div>
  );
}

function Frame14() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Frame">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Frame">
          <path d="M12 12H0V0H12V12Z" stroke="var(--stroke-0, #E5E7EB)" />
          <path d={svgPaths.p3d0f1180} fill="var(--fill-0, #6B7280)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Svg10() {
  return (
    <div className="absolute content-stretch flex items-center justify-center left-0 size-[12px] top-[1.5px]" data-name="svg">
      <Frame14 />
    </div>
  );
}

function I10() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[16px] left-[56.78px] top-[2px] w-[12px]" data-name="i">
      <Svg10 />
    </div>
  );
}

function Button6() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[20px] left-0 top-0 w-[84.781px]" data-name="button">
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[20px] left-[18.5px] not-italic text-[#6b7280] text-[14px] text-center top-0 w-[69px]">Last Week</p>
      <I10 />
    </div>
  );
}

function Div33() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[20px] left-[235px] top-[2px] w-[84.781px]" data-name="div">
      <Button6 />
    </div>
  );
}

function Div31() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-[24px] top-[24px] w-[320px]" data-name="div">
      <Div32 />
      <Div33 />
    </div>
  );
}

function Button7() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[36px] left-0 top-0 w-[81.438px]" data-name="button">
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium h-[20px] leading-[normal] left-[43.5px] not-italic text-[#6b7280] text-[14px] text-center top-[9px] w-[55px]">Income</p>
    </div>
  );
}

function Button8() {
  return (
    <div className="absolute bg-[#f9fafb] border-0 border-[#e5e7eb] border-solid h-[36px] left-[81.44px] rounded-[6px] top-0 w-[92.984px]" data-name="button">
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium h-[20px] leading-[normal] left-[49px] not-italic text-[14px] text-black text-center top-[9px] w-[66px]">Outcome</p>
    </div>
  );
}

function Button9() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[36px] left-[182.42px] top-0 w-[86.828px]" data-name="button">
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Medium',sans-serif] font-medium h-[20px] leading-[normal] left-[46px] not-italic text-[#6b7280] text-[14px] text-center top-[9px] w-[60px]">Pending</p>
    </div>
  );
}

function Div34() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[36px] left-[24px] top-[72px] w-[309px]" data-name="div">
      <Button7 />
      <Button8 />
      <Button9 />
    </div>
  );
}

function Span() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-[13.89px] top-[8px] w-[12.203px]" data-name="span">
      <p className="[word-break:break-word] absolute font-['Inter:Bold',sans-serif] font-bold h-[24px] leading-[normal] left-0 not-italic text-[#dc2626] text-[16px] top-[2px] w-[13px]">N</p>
    </div>
  );
}

function Div38() {
  return (
    <div className="absolute bg-[#fee2e2] border-0 border-[#e5e7eb] border-solid left-0 rounded-[6px] size-[40px] top-0" data-name="div">
      <Span />
    </div>
  );
}

function Div39() {
  return (
    <div className="[word-break:break-word] absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[40px] left-[52px] not-italic top-0 w-[116.141px]" data-name="div">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[24px] leading-[24px] left-0 text-[#1a1a1a] text-[16px] top-0 w-[117px]">Netflix Monthly</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[16px] leading-[16px] left-0 text-[#6b7280] text-[12px] top-[24px] w-[77px]">Subscription</p>
    </div>
  );
}

function Div37() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[40px] left-0 top-[12px] w-[168.141px]" data-name="div">
      <Div38 />
      <Div39 />
    </div>
  );
}

function Div40() {
  return (
    <div className="[word-break:break-word] absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[40px] left-[203px] not-italic top-[12px] w-[75.672px]" data-name="div">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[24px] leading-[24px] left-0 text-[#1a1a1a] text-[16px] top-0 w-[77px]">$3,839.91</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[16px] leading-[16px] left-[42.22px] text-[#6b7280] text-[12px] top-[24px] w-[34px]">06/27</p>
    </div>
  );
}

function Frame15() {
  return (
    <div className="h-[16px] relative shrink-0 w-[10px]" data-name="Frame">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 16">
        <g id="Frame">
          <path d="M10 16H0V0H10V16Z" stroke="var(--stroke-0, #E5E7EB)" />
          <path d={svgPaths.p2a458f00} fill="var(--fill-0, #9CA3AF)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Svg11() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-center justify-center left-0 top-[4px] w-[10px]" data-name="svg">
      <Frame15 />
    </div>
  );
}

function I11() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-[305px] top-[20px] w-[10px]" data-name="i">
      <Svg11 />
    </div>
  );
}

function Div36() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-[#e5e7eb] border-b border-solid h-[65px] left-0 top-0 w-[328px]" data-name="div">
      <Div37 />
      <Div40 />
      <I11 />
    </div>
  );
}

function Frame16() {
  return (
    <div className="h-[16px] relative shrink-0 w-[18px]" data-name="Frame">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18 16">
        <g id="Frame">
          <path d="M18 16H0V0H18V16Z" stroke="var(--stroke-0, #E5E7EB)" />
          <path d={svgPaths.p30bd3f00} fill="var(--fill-0, #DC2626)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Svg12() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-center justify-center left-0 top-[4px] w-[18px]" data-name="svg">
      <Frame16 />
    </div>
  );
}

function I12() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-[11px] top-[8px] w-[18px]" data-name="i">
      <Svg12 />
    </div>
  );
}

function Div43() {
  return (
    <div className="absolute bg-[#fee2e2] border-0 border-[#e5e7eb] border-solid left-0 rounded-[6px] size-[40px] top-0" data-name="div">
      <I12 />
    </div>
  );
}

function Div44() {
  return (
    <div className="[word-break:break-word] absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[40px] left-[52px] not-italic top-0 w-[135.281px]" data-name="div">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[24px] leading-[24px] left-0 text-[#1a1a1a] text-[16px] top-0 w-[136px]">Youtube Premium</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[16px] leading-[16px] left-0 text-[#6b7280] text-[12px] top-[24px] w-[77px]">Subscription</p>
    </div>
  );
}

function Div42() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[40px] left-0 top-[12px] w-[187.281px]" data-name="div">
      <Div43 />
      <Div44 />
    </div>
  );
}

function Div45() {
  return (
    <div className="[word-break:break-word] absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[40px] left-[202px] not-italic top-[12px] w-[79.125px]" data-name="div">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[24px] leading-[24px] left-0 text-[#1a1a1a] text-[16px] top-0 w-[80px]">$8,246.63</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[16px] leading-[16px] left-[45.67px] text-[#6b7280] text-[12px] top-[24px] w-[34px]">06/27</p>
    </div>
  );
}

function Frame17() {
  return (
    <div className="h-[16px] relative shrink-0 w-[10px]" data-name="Frame">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 16">
        <g id="Frame">
          <path d="M10 16H0V0H10V16Z" stroke="var(--stroke-0, #E5E7EB)" />
          <path d={svgPaths.p2a458f00} fill="var(--fill-0, #9CA3AF)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Svg13() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-center justify-center left-0 top-[4px] w-[10px]" data-name="svg">
      <Frame17 />
    </div>
  );
}

function I13() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-[305px] top-[20px] w-[10px]" data-name="i">
      <Svg13 />
    </div>
  );
}

function Div41() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-[#e5e7eb] border-b border-solid h-[65px] left-0 top-[81px] w-[328px]" data-name="div">
      <Div42 />
      <Div45 />
      <I13 />
    </div>
  );
}

function Frame18() {
  return (
    <div className="h-[16px] relative shrink-0 w-[15.5px]" data-name="Frame">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.5 16">
        <g id="Frame">
          <g clipPath="url(#clip0_1_1419)">
            <path d={svgPaths.p33d8f070} fill="var(--fill-0, #22C55E)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_1419">
            <path d="M0 0H15.5V16H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg14() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-center justify-center left-0 top-[4px] w-[15.5px]" data-name="svg">
      <Frame18 />
    </div>
  );
}

function I14() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-[12.25px] top-[8px] w-[15.5px]" data-name="i">
      <Svg14 />
    </div>
  );
}

function Div48() {
  return (
    <div className="absolute bg-[#dbeafe] border-0 border-[#e5e7eb] border-solid left-0 rounded-[6px] size-[40px] top-0" data-name="div">
      <I14 />
    </div>
  );
}

function Div49() {
  return (
    <div className="[word-break:break-word] absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[40px] left-[52px] not-italic top-0 w-[126.531px]" data-name="div">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[24px] leading-[24px] left-0 text-[#1a1a1a] text-[16px] top-0 w-[127px]">Spotify Premium</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[16px] leading-[16px] left-0 text-[#6b7280] text-[12px] top-[24px] w-[77px]">Subscription</p>
    </div>
  );
}

function Div47() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[40px] left-0 top-[12px] w-[178.531px]" data-name="div">
      <Div48 />
      <Div49 />
    </div>
  );
}

function Div50() {
  return (
    <div className="[word-break:break-word] absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[40px] left-[193px] not-italic top-[12px] w-[77px]" data-name="div">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium h-[24px] leading-[24px] left-0 text-[#1a1a1a] text-[16px] top-0 w-[77px]">$1,200.00</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal h-[16px] leading-[16px] left-[42.89px] text-[#6b7280] text-[12px] top-[24px] w-[35px]">06/26</p>
    </div>
  );
}

function Frame19() {
  return (
    <div className="h-[16px] relative shrink-0 w-[10px]" data-name="Frame">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10 16">
        <g id="Frame">
          <path d="M10 16H0V0H10V16Z" stroke="var(--stroke-0, #E5E7EB)" />
          <path d={svgPaths.p2a458f00} fill="var(--fill-0, #9CA3AF)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Svg15() {
  return (
    <div className="absolute content-stretch flex h-[16px] items-center justify-center left-0 top-[4px] w-[10px]" data-name="svg">
      <Frame19 />
    </div>
  );
}

function I15() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[24px] left-[305px] top-[20px] w-[10px]" data-name="i">
      <Svg15 />
    </div>
  );
}

function Div46() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-[#e5e7eb] border-b border-solid h-[65px] left-0 top-[162px] w-[328px]" data-name="div">
      <Div47 />
      <Div50 />
      <I15 />
    </div>
  );
}

function Div35() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[227px] left-[24px] top-[132px] w-[328px]" data-name="div">
      <Div36 />
      <Div41 />
      <Div46 />
    </div>
  );
}

function Span1() {
  return (
    <div className="bg-[rgba(0,0,0,0)] h-[20px] relative shrink-0 w-[45.688px]" data-name="span">
      <div aria-hidden className="absolute border-0 border-[#e5e7eb] border-solid inset-0 pointer-events-none" />
      <p className="-translate-x-1/2 [word-break:break-word] absolute font-['Inter:Regular',sans-serif] font-normal h-[20px] leading-[normal] left-[23px] not-italic text-[14px] text-black text-center top-px w-[46px]">See All</p>
    </div>
  );
}

function Frame20() {
  return (
    <div className="h-[14px] relative shrink-0 w-[12.25px]" data-name="Frame">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12.25 14">
        <g id="Frame">
          <g clipPath="url(#clip0_1_1402)">
            <path d={svgPaths.pde8daf0} fill="var(--fill-0, black)" id="Vector" />
          </g>
        </g>
        <defs>
          <clipPath id="clip0_1_1402">
            <path d="M0 0H12.25V14H0V0Z" fill="white" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Svg16() {
  return (
    <div className="absolute content-stretch flex h-[14px] items-center justify-center left-0 top-[2.75px] w-[12.25px]" data-name="svg">
      <Frame20 />
    </div>
  );
}

function I16() {
  return (
    <div className="bg-[rgba(0,0,0,0)] h-[20px] relative shrink-0 w-[12.25px]" data-name="i">
      <div aria-hidden className="absolute border-0 border-[#e5e7eb] border-solid inset-0 pointer-events-none" />
      <Svg16 />
    </div>
  );
}

function Frame32() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex gap-[8px] items-center left-[calc(50%-0.03px)] top-[8px]">
      <Span1 />
      <I16 />
    </div>
  );
}

function Button10() {
  return (
    <div className="absolute bg-[#f3f4f6] border-0 border-[#e5e7eb] border-solid h-[36px] left-0 rounded-[6px] top-0 w-[324px]" data-name="button">
      <Frame32 />
    </div>
  );
}

function Div51() {
  return (
    <div className="absolute bg-[rgba(0,0,0,0)] border-0 border-[#e5e7eb] border-solid h-[36px] left-[24px] top-[383px] w-[324px]" data-name="div">
      <Button10 />
    </div>
  );
}

function Div30() {
  return (
    <div className="bg-white drop-shadow-[0px_1px_1px_rgba(0,0,0,0.05)] h-[443px] relative rounded-[12px] shrink-0 w-[352px]" data-name="div">
      <div aria-hidden className="absolute border-0 border-[#e5e7eb] border-solid inset-0 pointer-events-none rounded-[12px]" />
      <Div31 />
      <Div34 />
      <Div35 />
      <Div51 />
    </div>
  );
}

function Title1() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[8px] items-center min-w-px relative" data-name="Title">
      <div className="overflow-clip relative shrink-0 size-[24px]" data-name="exchange-dollar-line">
        <div className="absolute inset-[8.34%_6.4%_8.32%_6.44%]" data-name="Vector">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.9186 20.0033">
            <path d={svgPaths.p152f6900} fill="var(--fill-0, #0D0D12)" id="Vector" />
          </svg>
        </div>
      </div>
      <p className="[word-break:break-word] flex-[1_0_0] font-['Poppins:Medium',sans-serif] leading-[1.4] min-w-px not-italic relative text-[#0d0d12] text-[16px]">Recent Transactions</p>
    </div>
  );
}

function SectionHeader1() {
  return (
    <div className="content-stretch flex gap-[16px] items-center relative shrink-0 w-full" data-name="Section header">
      <Title1 />
      <div className="bg-white content-stretch drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] flex gap-[8px] h-[32px] items-center justify-center px-[16px] py-[8px] relative rounded-[6px] shrink-0" data-name="Button">
        <div aria-hidden className="absolute border border-[#dfe1e7] border-solid inset-0 pointer-events-none rounded-[6px]" />
        <div className="overflow-clip relative shrink-0 size-[16px]" data-name="arrow-down-s-line">
          <div className="absolute inset-[34.26%_23.48%_33.33%_23.48%]" data-name="Vector">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8.48527 5.18548">
              <path d={svgPaths.p3cfa0180} fill="var(--fill-0, #0D0D12)" id="Vector" />
            </svg>
          </div>
        </div>
        <p className="[word-break:break-word] font-['Poppins:Medium',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#0d0d12] text-[12px] text-center tracking-[0.12px] whitespace-nowrap">Last Week</p>
      </div>
    </div>
  );
}

function Content1() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full" data-name="Content">
      <SectionHeader1 />
    </div>
  );
}

function Netflix() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="netflix">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="netflix">
          <path d={svgPaths.p6243f70} fill="url(#paint0_linear_1_1434)" id="vector" />
          <path d={svgPaths.p335a1380} fill="url(#paint1_linear_1_1434)" id="vector_2" />
          <path d={svgPaths.p2dea1600} fill="var(--fill-0, #E30A17)" id="vector_3" />
        </g>
        <defs>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_1434" x1="20.839" x2="13.2172" y1="17.1828" y2="20.53">
            <stop stopColor="#B20610" />
            <stop offset="0.255959" stopColor="#B20610" />
            <stop offset="1" stopColor="#590004" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint1_linear_1_1434" x1="2.99405" x2="11.2367" y1="6.12837" y2="2.5503">
            <stop stopColor="#B20610" />
            <stop offset="0.255959" stopColor="#B20610" />
            <stop offset="1" stopColor="#590004" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Button11() {
  return (
    <div className="bg-white content-stretch drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] flex items-center justify-center px-[16px] py-[8px] relative rounded-[1000px] shrink-0 size-[40px]" data-name="Button">
      <div aria-hidden className="absolute border border-[#dfe1e7] border-solid inset-0 pointer-events-none rounded-[1000px]" />
      <Netflix />
    </div>
  );
}

function Frame22() {
  return (
    <div className="[word-break:break-word] content-stretch flex flex-[1_0_0] flex-col items-start min-w-px not-italic relative">
      <p className="font-['Poppins:Medium',sans-serif] leading-[1.55] relative shrink-0 text-[#0d0d12] text-[14px] w-full">Netflix Monthly</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal h-[15px] leading-[16px] overflow-hidden relative shrink-0 text-[#818898] text-[12px] text-ellipsis w-full whitespace-nowrap" style={{ fontFeatureSettings: '"cv09", "ss11", "calt" 0, "liga" 0' }}>{`Montly Netflix subscription `}</p>
    </div>
  );
}

function DepositDetail1() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-center min-w-px relative" data-name="Deposit detail">
      <Frame22 />
    </div>
  );
}

function DepositDetail() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[12px] items-center min-w-px relative" data-name="Deposit Detail">
      <Button11 />
      <DepositDetail1 />
    </div>
  );
}

function DepositNominal1() {
  return (
    <div className="content-stretch flex flex-col items-end justify-center relative shrink-0 w-[64px]" data-name="Deposit Nominal">
      <div className="flex h-[23.11px] items-center justify-center relative shrink-0 w-full">
        <div className="flex-none rotate-1 w-full">
          <p className="[word-break:break-word] font-['Poppins:Medium',sans-serif] leading-[1.55] not-italic relative text-[#0d0d12] text-[14px] text-right w-full">$3,839.91</p>
        </div>
      </div>
      <p className="[word-break:break-word] font-['Poppins:Regular',sans-serif] leading-[1.55] not-italic relative shrink-0 text-[#818898] text-[12px] text-right w-full">06/27</p>
    </div>
  );
}

function DepositNominal() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-end relative shrink-0" data-name="Deposit Nominal">
      <DepositNominal1 />
      <div className="bg-white content-stretch flex items-center justify-center px-[16px] py-[8px] relative rounded-[1000px] shrink-0 size-[32px]" data-name="Button">
        <div className="overflow-clip relative shrink-0 size-[16px]" data-name="arrow-right-s-line">
          <div className="absolute inset-[23.49%_33.33%_23.48%_34.26%]" data-name="Vector">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5.18545 8.48525">
              <path d={svgPaths.p1122f000} fill="var(--fill-0, #0D0D12)" id="Vector" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function DepositItem() {
  return (
    <div className="content-stretch flex items-center justify-between py-[12px] relative shrink-0 w-full" data-name="Deposit item">
      <DepositDetail />
      <DepositNominal />
    </div>
  );
}

function Frame21() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Frame">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Frame">
          <path d={svgPaths.p1f1b6800} fill="var(--fill-0, #FF0000)" id="vector" />
          <path d={svgPaths.p3001cd00} fill="var(--fill-0, white)" id="vector_2" />
          <path d={svgPaths.p99f900} fill="var(--fill-0, white)" id="vector_3" />
        </g>
      </svg>
    </div>
  );
}

function Button12() {
  return (
    <div className="bg-white content-stretch drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] flex items-center justify-center px-[16px] py-[8px] relative rounded-[1000px] shrink-0 size-[40px]" data-name="Button">
      <div aria-hidden className="absolute border border-[#dfe1e7] border-solid inset-0 pointer-events-none rounded-[1000px]" />
      <Frame21 />
    </div>
  );
}

function Frame23() {
  return (
    <div className="[word-break:break-word] content-stretch flex flex-[1_0_0] flex-col items-start min-w-px not-italic relative">
      <p className="font-['Poppins:Medium',sans-serif] leading-[1.55] relative shrink-0 text-[#0d0d12] text-[14px] w-full">Youtube Premium</p>
      <p className="font-['Inter:Regular',sans-serif] font-normal h-[15px] leading-[16px] overflow-hidden relative shrink-0 text-[#818898] text-[12px] text-ellipsis w-full whitespace-nowrap" style={{ fontFeatureSettings: '"cv09", "ss11", "calt" 0, "liga" 0' }}>{`Montly Youtube subscription `}</p>
    </div>
  );
}

function DepositDetail3() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-center min-w-px relative" data-name="Deposit detail">
      <Frame23 />
    </div>
  );
}

function DepositDetail2() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[12px] items-center min-w-px relative" data-name="Deposit Detail">
      <Button12 />
      <DepositDetail3 />
    </div>
  );
}

function DepositNominal3() {
  return (
    <div className="content-stretch flex flex-col items-end justify-center relative shrink-0 w-[68px]" data-name="Deposit Nominal">
      <div className="flex h-[23.18px] items-center justify-center relative shrink-0 w-full">
        <div className="flex-none rotate-1 w-full">
          <p className="[word-break:break-word] font-['Poppins:Medium',sans-serif] leading-[1.55] not-italic relative text-[#0d0d12] text-[14px] text-right w-full">$8,246.63</p>
        </div>
      </div>
      <p className="[word-break:break-word] font-['Poppins:Regular',sans-serif] leading-[1.55] not-italic relative shrink-0 text-[#818898] text-[12px] text-right w-full">06/27</p>
    </div>
  );
}

function DepositNominal2() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-end relative shrink-0" data-name="Deposit Nominal">
      <DepositNominal3 />
      <div className="bg-white content-stretch flex items-center justify-center px-[16px] py-[8px] relative rounded-[1000px] shrink-0 size-[32px]" data-name="Button">
        <div className="overflow-clip relative shrink-0 size-[16px]" data-name="arrow-right-s-line">
          <div className="absolute inset-[23.49%_33.33%_23.48%_34.26%]" data-name="Vector">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5.18545 8.48525">
              <path d={svgPaths.p1122f000} fill="var(--fill-0, #0D0D12)" id="Vector" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function DepositItem1() {
  return (
    <div className="content-stretch flex items-center justify-between py-[12px] relative shrink-0 w-full" data-name="Deposit item">
      <DepositDetail2 />
      <DepositNominal2 />
    </div>
  );
}

function BodyCard() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full" data-name="Body Card">
      <div className="bg-[#dfe1e7] h-px relative shrink-0 w-full" data-name="Divider" />
      <DepositItem />
      <div className="bg-[#dfe1e7] h-px relative shrink-0 w-full" data-name="Divider" />
      <DepositItem1 />
      <div className="bg-[#dfe1e7] h-px relative shrink-0 w-full" data-name="Divider" />
    </div>
  );
}

function Card2() {
  return (
    <div className="bg-white h-[435px] relative rounded-[16px] shrink-0 w-[352px]" data-name="Card">
      <div className="content-stretch flex flex-col gap-[16px] items-center overflow-clip p-[16px] relative rounded-[inherit] size-full">
        <Content1 />
        <div className="bg-[#eceff3] content-stretch flex h-[32px] items-center justify-center p-[2px] relative rounded-[8px] shrink-0 w-[327px]" data-name="Segmented Controls">
          <div className="flex-[1_0_0] h-full min-w-px relative rounded-[8px]">
            <div className="-translate-x-1/2 -translate-y-1/2 [word-break:break-word] absolute flex flex-col font-['Poppins:Medium',sans-serif] justify-center leading-[0] left-1/2 not-italic text-[#666d80] text-[14px] text-center top-1/2 whitespace-nowrap">
              <p className="leading-[1.55]">Income</p>
            </div>
          </div>
          <div className="bg-white drop-shadow-[0px_0px_0.5px_rgba(20,20,20,0.04),0px_0px_4px_rgba(20,20,20,0.08)] flex-[1_0_0] h-full min-w-px relative rounded-[6px]">
            <div className="-translate-x-1/2 -translate-y-1/2 [word-break:break-word] absolute flex flex-col font-['Poppins:Medium',sans-serif] justify-center leading-[0] left-1/2 not-italic text-[#0d0d12] text-[14px] text-center top-1/2 whitespace-nowrap">
              <p className="leading-[1.55]">Outcome</p>
            </div>
          </div>
          <div className="flex-[1_0_0] h-full min-w-px relative rounded-[8px]">
            <div className="-translate-x-1/2 -translate-y-1/2 [word-break:break-word] absolute flex flex-col font-['Poppins:Medium',sans-serif] justify-center leading-[0] left-1/2 not-italic text-[#666d80] text-[14px] text-center top-1/2 whitespace-nowrap">
              <p className="leading-[1.55]">Pending</p>
            </div>
          </div>
        </div>
        <BodyCard />
        <div className="bg-white drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] h-[40px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
          <div aria-hidden className="absolute border border-[#dfe1e7] border-solid inset-0 pointer-events-none rounded-[8px]" />
          <div className="flex flex-row items-center justify-center size-full">
            <div className="content-stretch flex gap-[8px] items-center justify-center px-[16px] py-[8px] relative size-full">
              <p className="[word-break:break-word] font-['Poppins:Medium',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#0d0d12] text-[14px] text-center tracking-[0.14px] whitespace-nowrap">See All</p>
              <div className="overflow-clip relative shrink-0 size-[20px]" data-name="arrow-right-up-line">
                <div className="absolute bottom-[24.91%] left-[24.93%] right-[24.98%] top-1/4" data-name="Vector">
                  <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.0173 10.0173">
                    <path d={svgPaths.p2ac1ba00} fill="var(--fill-0, #0D0D12)" id="Vector" />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div aria-hidden className="absolute border border-[#dfe1e7] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[0px_1px_2px_0px_rgba(16,24,40,0.06)]" />
    </div>
  );
}

function Cards() {
  return (
    <div className="content-start flex flex-wrap gap-[24px] items-start relative shrink-0 w-[1104px]" data-name="Cards">
      <Div />
      <Div7 />
      <Card1 />
      <Div11 />
      <Div30 />
      <Card2 />
    </div>
  );
}

function MainContainer() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col gap-[24px] h-[1025px] items-start px-[32px] py-[24px] right-0 top-[6px] w-[1168px]" data-name="Main Container">
      <Header />
      <TabsFilters />
      <Cards />
    </div>
  );
}

export default function Component13HomeV() {
  return (
    <div className="bg-[#f6f8fa] relative size-full" data-name="13 . Home - V1">
      <div className="absolute bg-[#0d0d12] h-[1024px] left-0 top-0 w-[272px]" data-name="Sidebar">
        <div className="content-stretch flex flex-col items-start justify-between overflow-clip pb-[16px] relative rounded-[inherit] size-full">
          <Top />
          <Footer />
        </div>
        <div aria-hidden className="absolute border-[#dfe1e7] border-r border-solid inset-0 pointer-events-none shadow-[0px_12px_16px_-4px_rgba(13,13,18,0.08),0px_4px_6px_-2px_rgba(13,13,18,0.03)]" />
      </div>
      <MainContainer />
    </div>
  );
}