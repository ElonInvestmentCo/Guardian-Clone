import { useState } from "react";
import { toast, Toaster } from "sonner";
import svgPaths from "@/imports/13HomeV1/svg-eo6a1eepim";
import img03 from "@/imports/13HomeV1/3db12d1799a7bad8341541bf40270f41dcd8ffa3.png";
import img4 from "@/imports/13HomeV1/89fe31c79df8fb6bbfd99db1cb18960fb1e8e0e1.png";
import img5 from "@/imports/13HomeV1/3d5cb72fae1e058c2ed75ab981a9f8bb62e96a13.png";
import img6 from "@/imports/13HomeV1/75683fd57261c2ae940abab762a6e0130b36b3a9.png";
import img7 from "@/imports/13HomeV1/232a14a19c4d361cb9f54e38261e75afcd23b9b1.png";
import img8 from "@/imports/13HomeV1/f0d02ad2f4d075c1fa8155478e5bb26aaae69fc1.png";
import imgEllipse7Stroke from "@/imports/13HomeV1/4e2e7cd2575f87421b0491fda7a3c80c5bdbfc7b.png";
import imgEllipse7Stroke1 from "@/imports/13HomeV1/7296165096fd2dfead2ab6d44d1ba37ac4a2471d.png";
import imgEllipse7Stroke2 from "@/imports/13HomeV1/f694aef7df303cc3655f67652a5748d8a7cd9db1.png";

type NavItem = "dashboard" | "balance" | "cards" | "transactions" | "recipients" | "integrations" | "settings" | "help";
type TimePeriod = "12m" | "1m" | "7d" | "24h";
type CardType = "virtual" | "physical";
type TxTab = "income" | "outcome" | "pending";

// ─── Sidebar ─────────────────────────────────────────────────────────────────

function NavLink({
  icon,
  label,
  active,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`relative rounded-[6px] w-full flex flex-row items-center gap-[12px] px-[12px] py-[10px] cursor-pointer transition-colors text-left ${
        active ? "bg-white border border-[#dfe1e7]" : "hover:bg-white/10"
      }`}
    >
      {icon}
      <span
        className={`font-['Poppins:Medium',sans-serif] text-[14px] leading-[1.55] whitespace-nowrap ${
          active ? "font-['Poppins:SemiBold',sans-serif] text-[#0d0d12]" : "text-[#818898]"
        }`}
      >
        {label}
      </span>
    </button>
  );
}

function Sidebar({
  activeNav,
  setActiveNav,
  collapsed,
  setCollapsed,
  showSupport,
  setShowSupport,
}: {
  activeNav: NavItem;
  setActiveNav: (n: NavItem) => void;
  collapsed: boolean;
  setCollapsed: (v: boolean) => void;
  showSupport: boolean;
  setShowSupport: (v: boolean) => void;
}) {
  const navMain: { key: NavItem; label: string; icon: React.ReactNode }[] = [
    {
      key: "dashboard",
      label: "Dashboard",
      icon: (
        <div className="overflow-clip relative shrink-0 size-[20px]">
          <div className="absolute inset-[12.5%_16.67%]">
            <div className="absolute inset-[-5.56%_-6.25%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 16.6667">
                <path d={svgPaths.p26dd9b80} id="Icon" stroke={activeNav === "dashboard" ? "url(#db_grad)" : "url(#db_grad_off)"} strokeWidth="1.66667" />
                <defs>
                  <linearGradient gradientUnits="userSpaceOnUse" id="db_grad" x1="7.5" x2="7.5" y1="0.833333" y2="15.8333">
                    <stop stopColor="#272835" /><stop offset="1" stopColor="#72759B" />
                  </linearGradient>
                  <linearGradient gradientUnits="userSpaceOnUse" id="db_grad_off" x1="7.5" x2="7.5" y1="0.833333" y2="15.8333">
                    <stop stopColor="#818898" /><stop offset="1" stopColor="#BDC4D3" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      ),
    },
    {
      key: "balance",
      label: "Balance",
      icon: (
        <div className="overflow-clip relative shrink-0 size-[20px]">
          <div className="absolute inset-[16.68%_8.31%_16.65%_8.35%]">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.6667 13.3333">
              <path d={svgPaths.p5409000} fill="url(#cash_grad)" />
              <defs><linearGradient gradientUnits="userSpaceOnUse" id="cash_grad" x1="8.33334" x2="8.33334" y1="0" y2="13.3333"><stop stopColor="#818898" /><stop offset="1" stopColor="#BDC4D3" /></linearGradient></defs>
            </svg>
          </div>
        </div>
      ),
    },
    {
      key: "cards",
      label: "Cards",
      icon: (
        <div className="overflow-clip relative shrink-0 size-[20px]">
          <div className="absolute inset-[12.5%_8.31%_12.5%_8.35%]">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.6667 15">
              <path d={svgPaths.p13dcd780} fill="url(#card_grad)" />
              <defs><linearGradient gradientUnits="userSpaceOnUse" id="card_grad" x1="8.33334" x2="8.33334" y1="0" y2="15"><stop stopColor="#818898" /><stop offset="1" stopColor="#BDC4D3" /></linearGradient></defs>
            </svg>
          </div>
        </div>
      ),
    },
    {
      key: "transactions",
      label: "Transactions",
      icon: (
        <div className="overflow-clip relative shrink-0 size-[20px]">
          <div className="absolute inset-[10.42%]">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.8333 15.8333">
              <path d={svgPaths.p12cd9980} fill="url(#ex_grad)" />
              <defs><linearGradient gradientUnits="userSpaceOnUse" id="ex_grad" x1="7.91667" x2="7.91667" y1="0" y2="15.8333"><stop stopColor="#818898" /><stop offset="1" stopColor="#BDC4D3" /></linearGradient></defs>
            </svg>
          </div>
        </div>
      ),
    },
    {
      key: "recipients",
      label: "Recipients",
      icon: (
        <div className="overflow-clip relative shrink-0 size-[20px]">
          <div className="absolute inset-[8.33%]">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.6667 16.6667">
              <path d={svgPaths.p15370e40} fill="url(#team_grad)" />
              <defs><linearGradient gradientUnits="userSpaceOnUse" id="team_grad" x1="8.33333" x2="8.33333" y1="0" y2="16.6667"><stop stopColor="#818898" /><stop offset="1" stopColor="#BDC4D3" /></linearGradient></defs>
            </svg>
          </div>
        </div>
      ),
    },
  ];

  const navOther: { key: NavItem; label: string; icon: React.ReactNode }[] = [
    {
      key: "integrations",
      label: "Integrations",
      icon: (
        <div className="overflow-clip relative shrink-0 size-[20px]">
          <div className="absolute inset-[10.42%]">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.8333 15.8333">
              <path d={svgPaths.p2fb42d80} fill="url(#apps_grad)" />
              <defs><linearGradient gradientUnits="userSpaceOnUse" id="apps_grad" x1="7.91667" x2="7.91667" y1="0" y2="15.8333"><stop stopColor="#818898" /><stop offset="1" stopColor="#BDC4D3" /></linearGradient></defs>
            </svg>
          </div>
        </div>
      ),
    },
    {
      key: "settings",
      label: "Settings",
      icon: (
        <div className="overflow-clip relative shrink-0 size-[20px]">
          <div className="absolute inset-[8.33%_9.84%]">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.064 16.6695">
              <path d={svgPaths.p2d30e640} fill="url(#settings_grad)" />
              <defs><linearGradient gradientUnits="userSpaceOnUse" id="settings_grad" x1="8.03199" x2="8.03199" y1="7.83415e-09" y2="16.6695"><stop stopColor="#818898" /><stop offset="1" stopColor="#BDC4D3" /></linearGradient></defs>
            </svg>
          </div>
        </div>
      ),
    },
    {
      key: "help",
      label: "Get Help",
      icon: (
        <div className="overflow-clip relative shrink-0 size-[20px]">
          <div className="absolute inset-[8.33%]">
            <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.6667 16.6667">
              <path d={svgPaths.p15819080} fill="url(#help_grad)" />
              <defs><linearGradient gradientUnits="userSpaceOnUse" id="help_grad" x1="8.33333" x2="8.33333" y1="0" y2="16.6667"><stop stopColor="#818898" /><stop offset="1" stopColor="#BDC4D3" /></linearGradient></defs>
            </svg>
          </div>
        </div>
      ),
    },
  ];

  return (
    <div
      className="bg-[#0d0d12] flex flex-col items-start justify-between overflow-clip pb-[16px] shrink-0 transition-all duration-300 relative"
      style={{ width: collapsed ? 64 : 272, minHeight: 1024 }}
    >
      {/* border + shadow overlay */}
      <div aria-hidden className="absolute border-[#dfe1e7] border-r border-solid inset-0 pointer-events-none shadow-[0px_12px_16px_-4px_rgba(13,13,18,0.08),0px_4px_6px_-2px_rgba(13,13,18,0.03)]" />

      {/* TOP */}
      <div className="flex flex-col gap-[16px] items-start w-full">
        {/* Header */}
        <div className="flex flex-row items-center justify-between px-[20px] py-[24px] w-full">
          {!collapsed && (
            <div className="flex gap-[12px] items-center shrink-0">
              <div className="h-[36px] w-[36.183px] relative shrink-0">
                <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36.1833 36">
                  <path d={svgPaths.p34f28a80} fill="white" />
                </svg>
              </div>
              <div className="flex flex-col items-start">
                <span className="font-['Poppins:Medium',sans-serif] text-[#0d0d12] text-[16px] leading-[1.4] bg-white px-1 rounded-sm">LOGO</span>
                <span className="font-['Poppins:Regular',sans-serif] text-[#666d80] text-[12px] leading-[1.55]">Finance App</span>
              </div>
            </div>
          )}
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="bg-white drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] flex items-center justify-center rounded-[1000px] size-[32px] border border-[#dfe1e7] cursor-pointer hover:bg-gray-50 transition-colors shrink-0 ml-auto"
          >
            <div className="overflow-clip size-[16px] relative">
              <svg className="block size-full" fill="none" viewBox="0 0 5.18547 8.48525">
                <path d={collapsed ? svgPaths.p1122f000 : svgPaths.p1cb6ba00} fill="#0D0D12" />
              </svg>
            </div>
          </button>
        </div>

        {/* MAIN nav */}
        <div className="flex flex-col gap-[12px] items-start px-[12px] w-full">
          {!collapsed && (
            <span className="font-['Poppins:Medium',sans-serif] text-[#818898] text-[12px] leading-[1.55]">MAIN</span>
          )}
          <div className="flex flex-col gap-[2px] items-start w-full">
            {navMain.map((item) => (
              <NavLink
                key={item.key}
                icon={item.icon}
                label={collapsed ? "" : item.label}
                active={activeNav === item.key}
                onClick={() => {
                  setActiveNav(item.key);
                  if (item.key !== "dashboard") {
                    toast.info(`Navigating to ${item.label}`, { description: "This page is coming soon." });
                  }
                }}
              />
            ))}
          </div>
        </div>

        {/* OTHER nav */}
        <div className="flex flex-col gap-[12px] items-start px-[12px] w-full">
          {!collapsed && (
            <span className="font-['Poppins:Medium',sans-serif] text-[#818898] text-[12px] leading-[1.55]">OTHER</span>
          )}
          <div className="flex flex-col gap-[2px] items-start w-full">
            {navOther.map((item) => (
              <NavLink
                key={item.key}
                icon={item.icon}
                label={collapsed ? "" : item.label}
                active={activeNav === item.key}
                onClick={() => {
                  setActiveNav(item.key);
                  toast.info(`Opening ${item.label}`, { description: "This section is coming soon." });
                }}
              />
            ))}
          </div>
        </div>
      </div>

      {/* FOOTER */}
      {!collapsed && (
        <div className="flex flex-col gap-[12px] items-start px-[12px] w-full">
          {/* Support card */}
          {showSupport && (
            <div className="bg-white rounded-[8px] w-full overflow-clip">
              <div className="flex flex-col gap-[9px] items-start p-[12px]">
                <div className="flex items-center justify-between w-full">
                  <div className="flex gap-[8px] items-center">
                    <div className="overflow-clip size-[20px] relative">
                      <div className="absolute inset-[4.17%]">
                        <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 18.3333 18.3333">
                          <path d={svgPaths.p3f87480} fill="#0D0D12" />
                        </svg>
                      </div>
                    </div>
                    <p className="font-['Poppins:Medium',sans-serif] text-[#0d0d12] text-[14px] leading-[1.55] whitespace-nowrap">Need Support?</p>
                  </div>
                  <button
                    onClick={() => setShowSupport(false)}
                    className="overflow-clip size-[20px] relative cursor-pointer hover:opacity-70 transition-opacity"
                  >
                    <div className="absolute inset-[23.49%_23.48%_23.48%_23.48%]">
                      <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 10.6066 10.6066">
                        <path d={svgPaths.p1f073a00} fill="#0D0D12" />
                      </svg>
                    </div>
                  </button>
                </div>
                <p className="font-['Poppins:Regular',sans-serif] text-[#666d80] text-[12px] leading-[1.55] w-full">contact with one of our experts to get supports</p>
                <button
                  onClick={() => toast.success("Support request sent!", { description: "Our team will contact you shortly." })}
                  className="bg-white drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] h-[32px] rounded-[8px] w-full border border-[#dfe1e7] cursor-pointer hover:bg-gray-50 transition-colors flex items-center justify-center"
                >
                  <span className="font-['Poppins:Medium',sans-serif] text-[#0d0d12] text-[14px] text-center tracking-[0.14px]">Contact Us</span>
                </button>
              </div>
            </div>
          )}

          {/* User row */}
          <div className="flex items-center justify-between p-[12px] w-full rounded-[9px]">
            <div className="flex gap-[12px] items-center">
              <div className="overflow-clip relative rounded-[99px] size-[40px] shrink-0">
                <div className="absolute bg-[#b9cfd0] inset-0" />
                <img alt="User" className="absolute max-w-none object-cover size-full" src={img03} />
                <img alt="" className="absolute max-w-none object-cover size-full" src={img4} />
                <img alt="" className="absolute max-w-none object-cover size-full" src={img5} />
                <img alt="" className="absolute max-w-none object-cover size-full" src={img6} />
                <img alt="" className="absolute max-w-none object-cover size-full" src={img7} />
                <img alt="" className="absolute max-w-none object-cover size-full" src={img8} />
              </div>
              <div className="flex flex-col items-start">
                <span className="font-['Poppins:Medium',sans-serif] text-[#f8f5ff] text-[14px] leading-[1.55] whitespace-nowrap">Alexajohn</span>
                <span className="font-['Poppins:Regular',sans-serif] text-[#818898] text-[12px] leading-[1.55]">John@mail.com</span>
              </div>
            </div>
            <button
              onClick={() => toast.info("Logging out...", { description: "See you next time!" })}
              className="bg-white drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] flex items-center justify-center rounded-[1000px] size-[32px] border border-[#dfe1e7] cursor-pointer hover:bg-gray-50 transition-colors -scale-x-100"
            >
              <div className="overflow-clip size-[16px] relative">
                <svg className="block size-full" fill="none" viewBox="0 0 5.18547 8.48525">
                  <path d={svgPaths.p1cb6ba00} fill="#0D0D12" />
                </svg>
              </div>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── My Balance Card ──────────────────────────────────────────────────────────

function MyBalanceCard() {
  return (
    <div className="bg-white h-[306px] relative rounded-[12px] shrink-0 w-[351px] border border-[#e5e7eb]">
      {/* Header row */}
      <div className="absolute left-[25px] top-[25px] flex items-center justify-between w-[307px]">
        <div className="flex items-center gap-[8px]">
          <div className="relative size-[16px]">
            <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 16 16">
              <path d="M16 16H0V0H16V16Z" stroke="#E5E7EB" />
              <path d={svgPaths.p240fce00} fill="#4B5563" />
            </svg>
          </div>
          <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#1f2937] text-[16px] leading-[24px]">My Balance</span>
        </div>
        <button
          onClick={() => toast.info("Balance options", { description: "View more balance details." })}
          className="flex items-center gap-[4px] cursor-pointer hover:opacity-70 transition-opacity"
        >
          <span className="font-['Inter:Regular',sans-serif] text-[#9ca3af] text-[14px]">More Option</span>
          <div className="relative size-[14px]">
            <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 14 14">
              <g clipPath="url(#clip_mo)"><path d={svgPaths.p17782e00} fill="#9CA3AF" /></g>
              <defs><clipPath id="clip_mo"><path d="M0 0H14V14H0V0Z" fill="white" /></clipPath></defs>
            </svg>
          </div>
        </button>
      </div>

      {/* Currency */}
      <div className="absolute left-[25px] top-[65px] flex items-center gap-[8px]">
        <span className="font-['Inter:Regular',sans-serif] text-[#4b5563] text-[14px] leading-[20px]">US Dolar</span>
        <div className="overflow-clip size-[24px] relative">
          <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 24 24">
            <path d={svgPaths.p1c665200} fill="white" />
          </svg>
          <div className="absolute inset-0">
            <svg className="block size-full" fill="none" viewBox="0 0 24 24">
              <path d={svgPaths.p1c665200} fill="white" />
            </svg>
          </div>
        </div>
      </div>

      {/* Balance amount */}
      <div className="absolute left-[25px] top-[101px]">
        <span className="font-['Inter:Bold',sans-serif] font-bold text-[#1f2937] text-[30px] leading-[36px]">$63,48,100</span>
      </div>

      {/* Growth indicator */}
      <div className="absolute left-[25px] top-[145px] flex items-center gap-[4px]">
        <div className="relative size-[14px]">
          <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 14 14">
            <g clipPath="url(#clip_growth)"><path d={svgPaths.p1865080} fill="#16A34A" /></g>
            <defs><clipPath id="clip_growth"><path d="M0 0H14V14H0V0Z" fill="white" /></clipPath></defs>
          </svg>
        </div>
        <span className="font-['Inter:Regular',sans-serif] text-[#16a34a] text-[14px] leading-[20px]">15.43% Than last month</span>
      </div>

      {/* Action buttons */}
      <div className="absolute left-[25px] top-[240px] flex gap-[12px]">
        <button
          onClick={() => toast.success("Transfer initiated", { description: "Your send request is being processed." })}
          className="bg-[#1f2937] rounded-[8px] h-[48px] w-[147px] flex items-center justify-center gap-[10px] cursor-pointer hover:bg-[#374151] transition-colors active:scale-95"
        >
          <div className="relative h-[16px] w-[12px]">
            <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 12 16">
              <g clipPath="url(#clip_send)"><path d={svgPaths.p36e63c00} fill="white" /></g>
              <defs><clipPath id="clip_send"><path d="M0 0H12V16H0V0Z" fill="white" /></clipPath></defs>
            </svg>
          </div>
          <span className="font-['Inter:Regular',sans-serif] text-white text-[16px]">Send</span>
        </button>
        <button
          onClick={() => toast.success("Request sent", { description: "Your payment request has been sent." })}
          className="bg-[#1f2937] rounded-[8px] h-[48px] w-[147px] flex items-center justify-center gap-[10px] cursor-pointer hover:bg-[#374151] transition-colors active:scale-95"
        >
          <div className="relative h-[16px] w-[12px]">
            <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 12 16">
              <g clipPath="url(#clip_req)"><path d={svgPaths.p3f425280} fill="white" /></g>
              <defs><clipPath id="clip_req"><path d="M0 0H12V16H0V0Z" fill="white" /></clipPath></defs>
            </svg>
          </div>
          <span className="font-['Inter:Regular',sans-serif] text-white text-[16px]">Request</span>
        </button>
      </div>
    </div>
  );
}

// ─── My Cards Card ────────────────────────────────────────────────────────────

function MyCardsCard({ cardType, setCardType }: { cardType: CardType; setCardType: (v: CardType) => void }) {
  return (
    <div className="bg-white h-[306px] relative rounded-[12px] shrink-0 w-[347px] border border-[#e5e7eb]">
      {/* Header row */}
      <div className="absolute left-[24.66px] top-[25px] flex items-center justify-between w-[307px]">
        <div className="flex items-center gap-[8px]">
          <div className="relative h-[16px] w-[18px]">
            <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 18 16">
              <path d="M18 16H0V0H18V16Z" stroke="#E5E7EB" />
              <path d={svgPaths.p1db3ae0} fill="#4B5563" />
            </svg>
          </div>
          <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#1f2937] text-[16px] leading-[24px]">My Cards</span>
        </div>
        <button
          onClick={() => toast.info("Add a new card", { description: "Card management coming soon." })}
          className="font-['Inter:Regular',sans-serif] text-[#4b5563] text-[14px] cursor-pointer hover:opacity-70 transition-opacity"
        >
          + More Option
        </button>
      </div>

      {/* Virtual / Physical toggle */}
      <div className="absolute left-[24.66px] top-[65px] flex gap-[0px]">
        <button
          onClick={() => setCardType("virtual")}
          className={`rounded-[8px] h-[40px] px-4 text-[16px] transition-colors cursor-pointer ${
            cardType === "virtual" ? "bg-[#f3f4f6] text-[#1f2937]" : "text-[#4b5563] hover:bg-gray-50"
          }`}
        >
          <span className="font-['Inter:Regular',sans-serif]">Virtual</span>
        </button>
        <button
          onClick={() => setCardType("physical")}
          className={`rounded-[8px] h-[40px] px-4 text-[16px] transition-colors cursor-pointer ${
            cardType === "physical" ? "bg-[#f3f4f6] text-[#1f2937]" : "text-[#4b5563] hover:bg-gray-50"
          }`}
        >
          <span className="font-['Inter:Regular',sans-serif]">Physical</span>
        </button>
      </div>

      {/* Card visual */}
      <div className="absolute left-[25px] top-[115px]">
        <div className="bg-[#191b23] h-[180.81px] rounded-[11.301px] w-[307px] relative overflow-hidden">
          {/* Background mask */}
          <div className="absolute inset-0">
            <svg className="block size-full" fill="none" viewBox="0 0 286.232 180.81">
              <g>
                <mask id="mask_card" maskUnits="userSpaceOnUse" style={{ maskType: "alpha" }}>
                  <rect fill="#194BFB" height="180.81" rx="15.0675" width="286.232" />
                </mask>
                <g mask="url(#mask_card)">
                  <path d={svgPaths.p3d9e9900} fill="url(#card_bg_1)" fillOpacity="0.9" />
                  <path d={svgPaths.p34ad8d00} fill="url(#card_bg_2)" fillOpacity="0.9" />
                </g>
              </g>
              <defs>
                <linearGradient gradientUnits="userSpaceOnUse" id="card_bg_1" x1="86.2309" x2="209.031" y1="90.4051" y2="90.4051">
                  <stop stopColor="white" stopOpacity="0.15" /><stop offset="1" stopColor="white" stopOpacity="0" />
                </linearGradient>
                <linearGradient gradientUnits="userSpaceOnUse" id="card_bg_2" x1="195.487" x2="291.65" y1="90.4045" y2="90.4045">
                  <stop stopColor="white" stopOpacity="0.15" /><stop offset="1" stopColor="white" stopOpacity="0" />
                </linearGradient>
              </defs>
            </svg>
          </div>

          {/* Chip */}
          <div className="absolute" style={{ left: "16.31%", top: "45.55%", right: "75.36%", bottom: "45.01%" }}>
            <svg className="block size-full" fill="none" viewBox="0 0 28.8941 22.0146">
              <rect fill="url(#chip_grad)" height="21.5437" rx="3.53144" stroke="#9F7E3B" strokeWidth="0.470859" width="28.4233" x="0.235429" y="0.235429" />
              <path d={svgPaths.p1ba05140} stroke="black" strokeOpacity="0.76" strokeWidth="0.470859" />
              <path d={svgPaths.p1d349cc0} stroke="black" strokeOpacity="0.76" strokeWidth="0.470859" />
              <defs>
                <linearGradient gradientUnits="userSpaceOnUse" id="chip_grad" x1="0" x2="28.8941" y1="0" y2="22.1221">
                  <stop stopColor="#E6AC3C" /><stop offset="1" stopColor="#FFDA93" />
                </linearGradient>
              </defs>
            </svg>
          </div>

          {/* Balance label */}
          <div className="absolute text-white opacity-60 font-['Urbanist:Medium',sans-serif] font-medium text-[11.3px] tracking-[0.376px]" style={{ left: 57.51, top: 214.28 - 115 }}>
            Balance
          </div>
          {/* Balance amount */}
          <div className="absolute text-white font-['Urbanist:Bold',sans-serif] font-bold text-[22.6px]" style={{ left: 57.51, top: 237.76 - 115 }}>
            $24,098.00
          </div>

          {/* Visa logo area */}
          <div className="absolute right-[12px] bottom-[12px]">
            <div className="absolute" style={{ left: "68.62%", right: "12.41%", top: "48.62%", bottom: "48.07%" }}>
              <svg className="block w-[66px] h-[19px]" fill="none" viewBox="0 0 65.8546 19.422">
                <g>
                  <path d={svgPaths.p27009f00} fill="white" opacity="0.6" />
                  <path clipRule="evenodd" d={svgPaths.p3baf6c80} fill="white" fillRule="evenodd" />
                  <path d={svgPaths.pfe4fe00} fill="white" />
                  <path d={svgPaths.p30d4d0c0} fill="white" />
                  <path d={svgPaths.p47057f0} fill="white" />
                  <path d={svgPaths.p3a8bc80} fill="white" />
                  <path d={svgPaths.p29d22100} fill="white" />
                  <path d={svgPaths.p31297d00} fill="white" />
                  <path d={svgPaths.p1a6bac00} fill="white" />
                </g>
              </svg>
            </div>
          </div>
        </div>
      </div>

      {cardType === "physical" && (
        <div className="absolute left-[25px] top-[115px] h-[180.81px] w-[307px] bg-black/30 rounded-[11.301px] flex items-center justify-center">
          <span className="text-white font-['Poppins:Medium',sans-serif] text-[14px] opacity-80">Physical Card</span>
        </div>
      )}
    </div>
  );
}

// ─── Spending Summary Card ─────────────────────────────────────────────────────

function SpendingSummaryCard() {
  const [showMore, setShowMore] = useState(false);
  return (
    <div className="bg-white relative rounded-[16px] shrink-0 w-[352px] border border-[#dfe1e7] shadow-[0px_1px_2px_0px_rgba(16,24,40,0.06)]">
      <div className="flex flex-col gap-[16px] items-start overflow-clip p-[16px] relative rounded-[inherit]">
        {/* Section header */}
        <div className="flex gap-[16px] items-center w-full">
          <div className="flex flex-1 gap-[8px] items-center">
            <div className="overflow-clip relative shrink-0 size-[24px]">
              <div className="absolute inset-[2.08%_2.08%_8.33%_8.33%]">
                <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 21.5 21.5">
                  <path d={svgPaths.p27c2900} fill="#0D0D12" />
                </svg>
              </div>
            </div>
            <p className="font-['Poppins:Medium',sans-serif] text-[#0d0d12] text-[16px] leading-[1.4]">Spending Summary</p>
          </div>
          <div className="relative">
            <button
              onClick={() => setShowMore(!showMore)}
              className="bg-white drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] flex gap-[8px] h-[32px] items-center justify-center px-[16px] rounded-[6px] border border-[#dfe1e7] cursor-pointer hover:bg-gray-50 transition-colors"
            >
              <span className="font-['Poppins:Medium',sans-serif] text-[#0d0d12] text-[14px]">More Option</span>
              <div className="overflow-clip size-[16px] relative">
                <div className="absolute inset-[34.26%_23.48%_33.33%_23.48%]">
                  <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 8.48527 5.18548">
                    <path d={svgPaths.p3cfa0180} fill="#0D0D12" />
                  </svg>
                </div>
              </div>
            </button>
            {showMore && (
              <div className="absolute right-0 top-full mt-1 bg-white rounded-[8px] shadow-lg border border-[#dfe1e7] z-10 min-w-[140px]">
                {["This Month", "Last 3 Months", "This Year"].map((opt) => (
                  <button
                    key={opt}
                    onClick={() => { toast.info(opt + " selected"); setShowMore(false); }}
                    className="block w-full text-left px-4 py-2 text-[14px] font-['Poppins:Regular',sans-serif] text-[#0d0d12] hover:bg-gray-50 transition-colors"
                  >
                    {opt}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="bg-[#dfe1e7] h-px w-full" />

        {/* Pie chart */}
        <div className="h-[141px] relative w-[330px]">
          <div className="-translate-x-1/2 absolute bottom-0 flex flex-col gap-[4px] items-center justify-center left-[calc(50%-0.5px)] text-center">
            <p className="font-['Poppins:Medium',sans-serif] text-[#364152] text-[14px] leading-[1.55] w-[174px]">Spent</p>
            <p className="font-['Poppins:Medium',sans-serif] text-[#0d0d12] text-[24px] leading-[1.5] w-[251px]">$16,654,450</p>
          </div>
          <div className="absolute h-[144.427px] left-[25px] top-[-2px] w-[280px]">
            <div className="absolute inset-0 w-[280px] h-[144.427px]">
              <img alt="" className="absolute block inset-0 max-w-none size-full" src={imgEllipse7Stroke} />
            </div>
            <div className="absolute inset-[0_0.71%_0_0] w-[219.837px] h-[144.305px]">
              <img alt="" className="block max-w-none size-full" src={imgEllipse7Stroke1} />
            </div>
            <div className="absolute inset-[0.21%_0.14%_0_0] w-[133.367px] h-[143.697px]">
              <img alt="" className="block max-w-none size-full" src={imgEllipse7Stroke2} />
            </div>
          </div>
        </div>

        <div className="bg-[#dfe1e7] h-px w-full" />

        {/* Legend */}
        <div className="flex gap-[24px] items-center justify-center w-full">
          {[
            { color: "#1a1b25", label: "Outcome" },
            { color: "#99c0ff", label: "Income" },
            { color: "#c1c7d0", label: "Others" },
          ].map((l) => (
            <div key={l.label} className="flex gap-[4px] items-center">
              <div className="rounded-[29px] size-[10px] shrink-0" style={{ background: l.color }} />
              <span className="font-['Poppins:Regular',sans-serif] text-[#666d80] text-[12px] leading-[1.55]">{l.label}</span>
            </div>
          ))}
        </div>

        {/* Info bar */}
        <div className="bg-[#f0fbff] flex h-[32px] items-center justify-between px-[16px] rounded-[6px] w-[320px]">
          <p className="font-['Poppins:Regular',sans-serif] text-[12px] text-[#116b97]">
            {"Your weekly spending limit is "}
            <span className="font-['Poppins:SemiBold',sans-serif]">$2000.</span>
          </p>
          <div className="overflow-clip size-[16px] relative">
            <div className="absolute inset-[8.33%]">
              <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 13.3333 13.3333">
                <path d={svgPaths.p7d9e300} fill="#116B97" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Budget Overview Card ─────────────────────────────────────────────────────

const chartData = [
  { outcome: 96, income: 134 },
  { outcome: 145, income: 93 },
  { outcome: 116, income: 170 },
  { outcome: 191, income: 75 },
  { outcome: 129, income: 105, highlighted: true },
  { outcome: 142, income: 230 },
  { outcome: 117, income: 139 },
  { outcome: 147, income: 85 },
];
const months = ["JUN", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "NOV"];

function BudgetOverviewCard({ timePeriod }: { timePeriod: TimePeriod }) {
  const [tooltip, setTooltip] = useState<number | null>(null);

  const incomeByPeriod: Record<TimePeriod, string> = {
    "12m": "$17,843.33",
    "1m": "$17,843.33",
    "7d": "$4,210.50",
    "24h": "$987.00",
  };
  const expenseByPeriod: Record<TimePeriod, string> = {
    "12m": "$14,256.55",
    "1m": "$14,256.55",
    "7d": "$3,100.20",
    "24h": "$450.75",
  };

  return (
    <div className="bg-white h-[427px] relative rounded-[12px] shrink-0 w-[728px] border border-[#e5e7eb]">
      {/* Header */}
      <div className="absolute left-[25px] top-[25px] flex items-center justify-between w-[307px]">
        <div className="flex items-center gap-[8px]">
          <div className="relative h-[16px] w-[14px]">
            <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 14 16">
              <g clipPath="url(#clip_budget)"><path d={svgPaths.pe60b600} fill="#4B5563" /></g>
              <defs><clipPath id="clip_budget"><path d="M0 0H14V16H0V0Z" fill="white" /></clipPath></defs>
            </svg>
          </div>
          <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#1f2937] text-[16px] leading-[24px]">Budget Overview</span>
        </div>
        <div className="flex items-center gap-[12px]">
          <div className="flex items-center gap-[4px]">
            <div className="size-[12px] rounded-full bg-[#1f2937]" />
            <span className="font-['Inter:Regular',sans-serif] text-black text-[14px] leading-[20px]">Outcome</span>
          </div>
          <div className="flex items-center gap-[4px]">
            <div className="size-[12px] rounded-full bg-[#60a5fa]" />
            <span className="font-['Inter:Regular',sans-serif] text-black text-[14px] leading-[20px]">Income</span>
          </div>
        </div>
      </div>

      {/* Income / Expense numbers */}
      <div className="absolute left-[25px] top-[65px] flex gap-[16px]">
        <div>
          <div className="flex items-center gap-[6px]">
            <span className="font-['Inter:Regular',sans-serif] text-[#4b5563] text-[14px]">Income</span>
            <div className="relative h-[14px] w-[10.5px]">
              <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 10.5 14">
                <g clipPath="url(#clip_up)"><path d={svgPaths.p1432cb00} fill="#22C55E" /></g>
                <defs><clipPath id="clip_up"><path d="M0 0H10.5V14H0V0Z" fill="white" /></clipPath></defs>
              </svg>
            </div>
          </div>
          <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-black text-[20px] leading-[normal]">{incomeByPeriod[timePeriod]}</span>
        </div>
        <div className="ml-[20px]">
          <div className="flex items-center gap-[6px]">
            <span className="font-['Inter:Regular',sans-serif] text-[#4b5563] text-[14px]">Expense</span>
            <div className="relative h-[14px] w-[10.5px]">
              <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 10.5 14">
                <g clipPath="url(#clip_down)"><path d={svgPaths.p3b9d19f2} fill="#EF4444" /></g>
                <defs><clipPath id="clip_down"><path d="M0 0H10.5V14H0V0Z" fill="white" /></clipPath></defs>
              </svg>
            </div>
          </div>
          <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-black text-[20px]">{expenseByPeriod[timePeriod]}</span>
        </div>
      </div>

      {/* Bar chart */}
      <div className="-translate-x-1/2 absolute flex flex-col gap-[8px] items-center justify-end left-1/2 top-[141px]">
        <div className="flex gap-[24px] items-end relative h-[234px]">
          {/* Y-axis lines */}
          <div className="absolute bottom-0 right-0 w-[648px] h-[234px]">
            <svg className="block size-full" fill="none" viewBox="0 0 648 235">
              {[0.5, 47.3, 94.1, 140.9, 187.7, 234.5].map((y, i) => (
                <line key={i} stroke="#DFE1E7" x2="648" y1={y} y2={y} />
              ))}
            </svg>
          </div>
          {/* Y-axis labels */}
          <div className="flex flex-col gap-[36px] items-start justify-end font-['Inter:Regular',sans-serif] font-normal text-[#697586] text-[12px] leading-[18px] w-[48px] whitespace-nowrap z-10">
            {["50K", "40K", "30K", "20K", "10K", "0"].map((v) => (
              <span key={v}>{v}</span>
            ))}
          </div>
          {/* Bars */}
          <div className="flex gap-[28px] h-full items-end z-10">
            {chartData.map((d, i) => (
              <div
                key={i}
                className="relative flex gap-[4px] h-full items-end cursor-pointer"
                onMouseEnter={() => setTooltip(i)}
                onMouseLeave={() => setTooltip(null)}
              >
                {/* Tooltip */}
                {tooltip === i && (
                  <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 bg-[#1f2937] text-white rounded-[4px] p-2 text-[12px] whitespace-nowrap z-20 font-['Inter:Regular',sans-serif]">
                    <div className="font-['Inter:Medium',sans-serif] font-medium">{months[i]}</div>
                    <div className="text-[#4ade80]">+16.2%</div>
                    <div className="text-[#f87171]">-{Math.round(d.outcome / 4)}%</div>
                  </div>
                )}
                <div
                  className="w-[24px] rounded-t-[4px] transition-all duration-200"
                  style={{
                    height: d.outcome,
                    background: d.highlighted ? "#CCE0FF" : "#E5EFFF",
                  }}
                />
                <div
                  className="w-[24px] rounded-t-[4px] transition-all duration-200"
                  style={{
                    height: d.income,
                    background: d.highlighted ? "#1A1B25" : "#666D80",
                  }}
                />
              </div>
            ))}
          </div>
        </div>

        {/* X-axis months */}
        <div className="flex gap-[24px] items-center w-full pl-[72px]">
          <div className="w-[48px]" />
          {months.map((m, i) => (
            <span
              key={i}
              className={`font-['Poppins:Regular',sans-serif] text-[12px] text-center w-[52px] ${i === 4 ? "text-[#0d0d12]" : "text-[#697586]"}`}
            >
              {m}
            </span>
          ))}
        </div>
      </div>

      {/* Tooltip box on the chart (Sep) */}
      <div className="absolute left-[389px] top-[134px] bg-[#1f2937] rounded-[4px] h-[80px] w-[87.609px] p-[8px]">
        <p className="font-['Inter:Medium',sans-serif] font-medium text-white text-[12px]">SEPTEMBER</p>
        <p className="font-['Inter:Regular',sans-serif] text-[#4ade80] text-[12px]">426 ↑16.2%</p>
        <p className="font-['Inter:Regular',sans-serif] text-[#f87171] text-[12px]">1,256</p>
        <p className="font-['Inter:Regular',sans-serif] text-[#f87171] text-[12px]">↓32.5%</p>
      </div>
    </div>
  );
}

// ─── Recent Transactions (legacy style) ──────────────────────────────────────

function RecentTransactionsLegacy({ txTab, setTxTab }: { txTab: TxTab; setTxTab: (v: TxTab) => void }) {
  const transactions = [
    { icon: "N", iconBg: "#fee2e2", iconColor: "#dc2626", name: "Netflix Monthly", category: "Subscription", amount: "$3,839.91", date: "06/27" },
    { icon: "YT", iconBg: "#fee2e2", iconColor: "#dc2626", name: "Youtube Premium", category: "Subscription", amount: "$8,246.63", date: "06/27" },
    { icon: "S", iconBg: "#dbeafe", iconColor: "#22c55e", name: "Spotify Premium", category: "Subscription", amount: "$1,200.00", date: "06/26" },
  ];

  const tabs: { key: TxTab; label: string }[] = [
    { key: "income", label: "Income" },
    { key: "outcome", label: "Outcome" },
    { key: "pending", label: "Pending" },
  ];

  return (
    <div className="bg-white drop-shadow-[0px_1px_1px_rgba(0,0,0,0.05)] h-[443px] relative rounded-[12px] shrink-0 w-[352px]">
      {/* Header */}
      <div className="absolute left-[24px] top-[24px] flex items-center justify-between w-[320px]">
        <div className="flex items-center gap-[6px]">
          <div className="relative size-[16px]">
            <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 16 16">
              <path d="M16 16H0V0H16V16Z" stroke="#E5E7EB" />
              <path d={svgPaths.p1c578e00} fill="#1A1A1A" />
            </svg>
          </div>
          <span className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#1a1a1a] text-[16px] leading-[24px]">Recent Transactions</span>
        </div>
        <button
          onClick={() => toast.info("Filter by time period")}
          className="flex items-center gap-[4px] cursor-pointer hover:opacity-70 transition-opacity"
        >
          <span className="font-['Inter:Regular',sans-serif] text-[#6b7280] text-[14px]">Last Week</span>
          <div className="relative size-[12px]">
            <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 12 12">
              <path d="M12 12H0V0H12V12Z" stroke="#E5E7EB" />
              <path d={svgPaths.p3d0f1180} fill="#6B7280" />
            </svg>
          </div>
        </button>
      </div>

      {/* Tabs */}
      <div className="absolute left-[24px] top-[72px] flex gap-[0]">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setTxTab(tab.key)}
            className={`h-[36px] px-[16px] rounded-[6px] cursor-pointer transition-colors font-['Inter:Medium',sans-serif] font-medium text-[14px] ${
              txTab === tab.key ? "bg-[#f9fafb] text-black" : "text-[#6b7280] hover:bg-gray-50"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Transaction list */}
      <div className="absolute left-[24px] top-[132px] w-[328px]">
        {transactions.map((tx, i) => (
          <div key={i} className="border-b border-[#e5e7eb] h-[65px] flex items-center justify-between">
            <div className="flex items-center gap-[12px]">
              <div className="rounded-[6px] size-[40px] flex items-center justify-center shrink-0" style={{ background: tx.iconBg }}>
                <span className="font-['Inter:Bold',sans-serif] font-bold text-[16px]" style={{ color: tx.iconColor }}>{tx.icon}</span>
              </div>
              <div>
                <p className="font-['Inter:Medium',sans-serif] font-medium text-[#1a1a1a] text-[16px] leading-[24px]">{tx.name}</p>
                <p className="font-['Inter:Regular',sans-serif] text-[#6b7280] text-[12px] leading-[16px]">{tx.category}</p>
              </div>
            </div>
            <div className="flex items-center gap-[8px]">
              <div className="text-right">
                <p className="font-['Inter:Medium',sans-serif] font-medium text-[#1a1a1a] text-[16px] leading-[24px]">{tx.amount}</p>
                <p className="font-['Inter:Regular',sans-serif] text-[#6b7280] text-[12px] leading-[16px]">{tx.date}</p>
              </div>
              <button
                onClick={() => toast.info(`${tx.name} details`, { description: `Amount: ${tx.amount} on ${tx.date}` })}
                className="cursor-pointer hover:opacity-70 transition-opacity"
              >
                <div className="relative h-[16px] w-[10px]">
                  <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 10 16">
                    <path d="M10 16H0V0H10V16Z" stroke="#E5E7EB" />
                    <path d={svgPaths.p2a458f00} fill="#9CA3AF" />
                  </svg>
                </div>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* See All button */}
      <div className="absolute left-[24px] top-[383px] w-[324px]">
        <button
          onClick={() => toast.info("Viewing all transactions", { description: "Full transaction history coming soon." })}
          className="bg-[#f3f4f6] rounded-[6px] h-[36px] w-full flex items-center justify-center gap-[8px] cursor-pointer hover:bg-gray-200 transition-colors"
        >
          <span className="font-['Inter:Regular',sans-serif] text-black text-[14px]">See All</span>
          <div className="relative h-[14px] w-[12.25px]">
            <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 12.25 14">
              <g clipPath="url(#clip_arrow)"><path d={svgPaths.pde8daf0} fill="black" /></g>
              <defs><clipPath id="clip_arrow"><path d="M0 0H12.25V14H0V0Z" fill="white" /></clipPath></defs>
            </svg>
          </div>
        </button>
      </div>
    </div>
  );
}

// ─── Recent Transactions (Poppins style) ─────────────────────────────────────

function NetflixIcon() {
  return (
    <div className="relative size-[24px]">
      <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 24 24">
        <path d={svgPaths.p6243f70} fill="url(#nf_g1)" />
        <path d={svgPaths.p335a1380} fill="url(#nf_g2)" />
        <path d={svgPaths.p2dea1600} fill="#E30A17" />
        <defs>
          <linearGradient gradientUnits="userSpaceOnUse" id="nf_g1" x1="20.839" x2="13.2172" y1="17.1828" y2="20.53">
            <stop stopColor="#B20610" /><stop offset="0.255959" stopColor="#B20610" /><stop offset="1" stopColor="#590004" />
          </linearGradient>
          <linearGradient gradientUnits="userSpaceOnUse" id="nf_g2" x1="2.99405" x2="11.2367" y1="6.12837" y2="2.5503">
            <stop stopColor="#B20610" /><stop offset="0.255959" stopColor="#B20610" /><stop offset="1" stopColor="#590004" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function YoutubeIcon() {
  return (
    <div className="relative size-[24px]">
      <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 24 24">
        <path d={svgPaths.p1f1b6800} fill="#FF0000" />
        <path d={svgPaths.p3001cd00} fill="white" />
        <path d={svgPaths.p99f900} fill="white" />
      </svg>
    </div>
  );
}

const poppinsTransactions = [
  { IconComp: NetflixIcon, name: "Netflix Monthly", desc: "Montly Netflix subscription", amount: "$3,839.91", date: "06/27" },
  { IconComp: YoutubeIcon, name: "Youtube Premium", desc: "Montly Youtube subscription", amount: "$8,246.63", date: "06/27" },
];

function RecentTransactionsPoppins({ txTab, setTxTab }: { txTab: TxTab; setTxTab: (v: TxTab) => void }) {
  const [lastWeekOpen, setLastWeekOpen] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState("Last Week");

  return (
    <div className="bg-white h-[435px] relative rounded-[16px] shrink-0 w-[352px] border border-[#dfe1e7] shadow-[0px_1px_2px_0px_rgba(16,24,40,0.06)]">
      <div className="flex flex-col gap-[16px] items-center overflow-clip p-[16px] relative rounded-[inherit] size-full">

        {/* Section header */}
        <div className="flex gap-[16px] items-center w-full">
          <div className="flex flex-1 gap-[8px] items-center">
            <div className="overflow-clip relative shrink-0 size-[24px]">
              <div className="absolute inset-[8.34%_6.4%_8.32%_6.44%]">
                <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 20.9186 20.0033">
                  <path d={svgPaths.p152f6900} fill="#0D0D12" />
                </svg>
              </div>
            </div>
            <p className="font-['Poppins:Medium',sans-serif] text-[#0d0d12] text-[16px] leading-[1.4] flex-1">Recent Transactions</p>
          </div>
          <div className="relative">
            <button
              onClick={() => setLastWeekOpen(!lastWeekOpen)}
              className="bg-white drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] flex gap-[8px] h-[32px] items-center justify-center px-[16px] rounded-[6px] border border-[#dfe1e7] cursor-pointer hover:bg-gray-50 transition-colors"
            >
              <div className="overflow-clip size-[16px] relative">
                <div className="absolute inset-[34.26%_23.48%_33.33%_23.48%]">
                  <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 8.48527 5.18548">
                    <path d={svgPaths.p3cfa0180} fill="#0D0D12" />
                  </svg>
                </div>
              </div>
              <span className="font-['Poppins:Medium',sans-serif] text-[#0d0d12] text-[12px] tracking-[0.12px]">{selectedPeriod}</span>
            </button>
            {lastWeekOpen && (
              <div className="absolute right-0 top-full mt-1 bg-white rounded-[8px] shadow-lg border border-[#dfe1e7] z-10 min-w-[120px]">
                {["Last Week", "Last Month", "Last 3 Months"].map((opt) => (
                  <button
                    key={opt}
                    onClick={() => { setSelectedPeriod(opt); setLastWeekOpen(false); toast.info(opt + " selected"); }}
                    className="block w-full text-left px-4 py-2 text-[12px] font-['Poppins:Regular',sans-serif] text-[#0d0d12] hover:bg-gray-50 transition-colors"
                  >
                    {opt}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Segmented tabs */}
        <div className="bg-[#eceff3] flex h-[32px] items-center p-[2px] rounded-[8px] w-[327px]">
          {(["income", "outcome", "pending"] as TxTab[]).map((tab) => (
            <button
              key={tab}
              onClick={() => setTxTab(tab)}
              className={`flex-1 h-full rounded-[6px] cursor-pointer transition-all font-['Poppins:Medium',sans-serif] text-[14px] capitalize ${
                txTab === tab
                  ? "bg-white shadow-[0px_0px_0.5px_rgba(20,20,20,0.04),0px_0px_4px_rgba(20,20,20,0.08)] text-[#0d0d12]"
                  : "text-[#666d80] hover:text-[#0d0d12]"
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>

        {/* Transaction items */}
        <div className="flex flex-col gap-[8px] items-start w-full">
          <div className="bg-[#dfe1e7] h-px w-full" />
          {poppinsTransactions.map((tx, i) => (
            <div key={i} className="w-full">
              <div className="flex items-center justify-between py-[12px] w-full">
                <div className="flex flex-1 gap-[12px] items-center">
                  <button className="bg-white drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] flex items-center justify-center px-[16px] py-[8px] rounded-[1000px] size-[40px] border border-[#dfe1e7] cursor-pointer hover:scale-105 transition-transform">
                    <tx.IconComp />
                  </button>
                  <div className="flex flex-1 flex-col items-start">
                    <p className="font-['Poppins:Medium',sans-serif] text-[#0d0d12] text-[14px] leading-[1.55] w-full">{tx.name}</p>
                    <p className="font-['Inter:Regular',sans-serif] font-normal text-[#818898] text-[12px] leading-[16px] w-full overflow-hidden text-ellipsis whitespace-nowrap">{tx.desc}</p>
                  </div>
                </div>
                <div className="flex gap-[4px] items-center justify-end shrink-0">
                  <div className="flex flex-col items-end w-[64px]">
                    <p className="font-['Poppins:Medium',sans-serif] text-[#0d0d12] text-[14px] text-right w-full">{tx.amount}</p>
                    <p className="font-['Poppins:Regular',sans-serif] text-[#818898] text-[12px] text-right w-full">{tx.date}</p>
                  </div>
                  <button
                    onClick={() => toast.info(`${tx.name} details`, { description: `Amount: ${tx.amount} · ${tx.date}` })}
                    className="bg-white flex items-center justify-center rounded-[1000px] size-[32px] cursor-pointer hover:bg-gray-50 transition-colors"
                  >
                    <div className="overflow-clip size-[16px] relative">
                      <div className="absolute inset-[23.49%_33.33%_23.48%_34.26%]">
                        <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 5.18545 8.48525">
                          <path d={svgPaths.p1122f000} fill="#0D0D12" />
                        </svg>
                      </div>
                    </div>
                  </button>
                </div>
              </div>
              <div className="bg-[#dfe1e7] h-px w-full" />
            </div>
          ))}
        </div>

        {/* See All button */}
        <button
          onClick={() => toast.info("Viewing all transactions", { description: "Full transaction history coming soon." })}
          className="bg-white drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] h-[40px] relative rounded-[8px] w-full border border-[#dfe1e7] cursor-pointer hover:bg-gray-50 transition-colors flex items-center justify-center gap-[8px]"
        >
          <span className="font-['Poppins:Medium',sans-serif] text-[#0d0d12] text-[14px] tracking-[0.14px]">See All</span>
          <div className="overflow-clip size-[20px] relative">
            <div className="absolute bottom-[24.91%] left-[24.93%] right-[24.98%] top-1/4">
              <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 10.0173 10.0173">
                <path d={svgPaths.p2ac1ba00} fill="#0D0D12" />
              </svg>
            </div>
          </div>
        </button>
      </div>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────

export default function App() {
  const [activeNav, setActiveNav] = useState<NavItem>("dashboard");
  const [timePeriod, setTimePeriod] = useState<TimePeriod>("1m");
  const [cardType, setCardType] = useState<CardType>("virtual");
  const [txTab, setTxTab] = useState<TxTab>("outcome");
  const [showSupport, setShowSupport] = useState(true);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [showExchangeRate, setShowExchangeRate] = useState(false);

  const timePeriodLabels: Record<TimePeriod, string> = {
    "12m": "12 M", "1m": "1 M", "7d": "7 D", "24h": "24 H",
  };

  return (
    <div className="bg-[#f6f8fa] flex min-h-screen w-full">
      <Toaster position="top-right" richColors />

      {/* Sidebar */}
      <Sidebar
        activeNav={activeNav}
        setActiveNav={setActiveNav}
        collapsed={sidebarCollapsed}
        setCollapsed={setSidebarCollapsed}
        showSupport={showSupport}
        setShowSupport={setShowSupport}
      />

      {/* Main Content */}
      <div className="bg-white flex flex-col gap-[24px] flex-1 items-start px-[32px] py-[24px] min-h-screen">
        {/* Header */}
        <div className="flex items-center justify-between w-full">
          <div className="flex flex-1 flex-col gap-[4px]">
            <p className="font-['Poppins:Medium',sans-serif] text-[#0d0d12] text-[24px] leading-[1.5]">Your Financial Dashboard</p>
            <p className="font-['Poppins:Regular',sans-serif] text-[#666d80] text-[16px] leading-[1.6]">Welcome back, Max Verstappen!</p>
          </div>
          <div className="flex gap-[20px] items-center shrink-0">
            {/* Search */}
            <button
              onClick={() => toast.info("Search", { description: "Search functionality coming soon." })}
              className="bg-white flex items-center justify-center rounded-[1000px] size-[48px] cursor-pointer hover:bg-gray-50 transition-colors"
            >
              <div className="overflow-clip size-[20px] relative">
                <div className="absolute inset-[8.33%_7.03%_7.03%_8.33%]">
                  <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 16.9281 16.9281">
                    <path d={svgPaths.pb781390} fill="#0D0D12" />
                  </svg>
                </div>
              </div>
            </button>
            {/* Notifications */}
            <button
              onClick={() => toast.info("Notifications", { description: "You have 3 unread notifications." })}
              className="bg-white flex items-center justify-center rounded-[1000px] size-[48px] cursor-pointer hover:bg-gray-50 transition-colors"
            >
              <div className="overflow-clip size-[20px] relative">
                <div className="absolute inset-[8.33%_8.33%_2.08%_8.33%]">
                  <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 16.6667 17.9167">
                    <path d={svgPaths.p17e5fd00} fill="#0D0D12" />
                  </svg>
                </div>
              </div>
            </button>
            {/* Exchange Rate */}
            <div className="relative">
              <button
                onClick={() => setShowExchangeRate(!showExchangeRate)}
                className="bg-white drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] flex gap-[8px] h-[48px] items-center justify-center px-[16px] rounded-[10px] border border-[#dfe1e7] cursor-pointer hover:bg-gray-50 transition-colors"
              >
                <span className="font-['Poppins:Medium',sans-serif] text-[#0d0d12] text-[16px] tracking-[0.16px] whitespace-nowrap"> Exchange Rate</span>
              </button>
              {showExchangeRate && (
                <div className="absolute right-0 top-full mt-2 bg-white rounded-[12px] shadow-lg border border-[#dfe1e7] z-20 p-4 min-w-[220px]">
                  <p className="font-['Poppins:Medium',sans-serif] text-[#0d0d12] text-[14px] mb-3">Live Exchange Rates</p>
                  {[
                    { pair: "USD/EUR", rate: "0.9214" },
                    { pair: "USD/GBP", rate: "0.7892" },
                    { pair: "USD/JPY", rate: "149.82" },
                    { pair: "USD/INR", rate: "83.25" },
                  ].map((r) => (
                    <div key={r.pair} className="flex justify-between py-1">
                      <span className="font-['Poppins:Regular',sans-serif] text-[#666d80] text-[13px]">{r.pair}</span>
                      <span className="font-['Poppins:Medium',sans-serif] text-[#0d0d12] text-[13px]">{r.rate}</span>
                    </div>
                  ))}
                  <button
                    onClick={() => setShowExchangeRate(false)}
                    className="mt-3 w-full bg-[#0d0d12] text-white rounded-[8px] py-2 text-[13px] font-['Poppins:Medium',sans-serif] cursor-pointer hover:bg-[#1a1b25] transition-colors"
                  >
                    Close
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Tabs + Filters */}
        <div className="flex items-end justify-between w-full">
          {/* Time period segmented control */}
          <div className="bg-[#eceff3] flex items-center p-[2px] rounded-[8px] h-[40px] w-[327px]">
            {(["12m", "1m", "7d", "24h"] as TimePeriod[]).map((p) => (
              <button
                key={p}
                onClick={() => setTimePeriod(p)}
                className={`flex-1 h-full rounded-[6px] cursor-pointer transition-all font-['Poppins:Medium',sans-serif] text-[14px] ${
                  timePeriod === p
                    ? "bg-white shadow-[0px_0px_0.5px_rgba(20,20,20,0.04),0px_0px_4px_rgba(20,20,20,0.08)] text-[#0d0d12]"
                    : "text-[#666d80] hover:text-[#0d0d12]"
                }`}
              >
                {timePeriodLabels[p]}
              </button>
            ))}
          </div>

          {/* Filter actions */}
          <div className="flex gap-[12px] items-start">
            <button
              onClick={() => toast.info("Date range picker", { description: "Select a custom date range." })}
              className="bg-white drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] flex gap-[8px] h-[40px] items-center justify-center px-[16px] rounded-[8px] border border-[#dfe1e7] cursor-pointer hover:bg-gray-50 transition-colors"
            >
              <div className="overflow-clip size-[20px] relative">
                <div className="absolute inset-[4.17%_8.33%_12.5%_8.33%]">
                  <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 16.6667 16.6667">
                    <path d={svgPaths.p2b074300} fill="#0D0D12" />
                  </svg>
                </div>
              </div>
              <span className="font-['Poppins:Medium',sans-serif] text-[#0d0d12] text-[14px] tracking-[0.14px] whitespace-nowrap">8 Feb - 15 Feb 2024</span>
            </button>
            <button
              onClick={() => toast.info("Filters", { description: "Advanced filters coming soon." })}
              className="bg-white drop-shadow-[0px_1px_1px_rgba(13,13,18,0.06)] flex gap-[8px] h-[40px] items-center justify-center px-[16px] rounded-[8px] border border-[#dfe1e7] cursor-pointer hover:bg-gray-50 transition-colors"
            >
              <div className="overflow-clip size-[20px] relative">
                <div className="absolute bottom-1/4 left-[12.5%] right-[12.5%] top-1/4">
                  <svg className="absolute block inset-0 size-full" fill="none" viewBox="0 0 15 10">
                    <path d={svgPaths.p2cb87d00} fill="#0D0D12" />
                  </svg>
                </div>
              </div>
              <span className="font-['Poppins:Medium',sans-serif] text-[#0d0d12] text-[14px] tracking-[0.14px]">Filter</span>
            </button>
          </div>
        </div>

        {/* Cards Grid */}
        <div className="flex flex-wrap gap-[24px] items-start w-full">
          <MyBalanceCard />
          <MyCardsCard cardType={cardType} setCardType={setCardType} />
          <SpendingSummaryCard />
          <BudgetOverviewCard timePeriod={timePeriod} />
          <RecentTransactionsLegacy txTab={txTab} setTxTab={setTxTab} />
          <RecentTransactionsPoppins txTab={txTab} setTxTab={setTxTab} />
        </div>
      </div>
    </div>
  );
}
